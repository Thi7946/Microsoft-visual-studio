﻿namespace thiwakron_2
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TBUSERNAME = new System.Windows.Forms.TextBox();
            this.TBPASSWORD = new System.Windows.Forms.TextBox();
            this.BTLOGIN = new System.Windows.Forms.Button();
            this.CBPW = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(107, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "USER NAME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(107, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "PASSWORD";
            // 
            // TBUSERNAME
            // 
            this.TBUSERNAME.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBUSERNAME.Location = new System.Drawing.Point(334, 131);
            this.TBUSERNAME.Name = "TBUSERNAME";
            this.TBUSERNAME.Size = new System.Drawing.Size(208, 32);
            this.TBUSERNAME.TabIndex = 2;
            // 
            // TBPASSWORD
            // 
            this.TBPASSWORD.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBPASSWORD.Location = new System.Drawing.Point(334, 188);
            this.TBPASSWORD.Name = "TBPASSWORD";
            this.TBPASSWORD.PasswordChar = '*';
            this.TBPASSWORD.Size = new System.Drawing.Size(208, 32);
            this.TBPASSWORD.TabIndex = 3;
            // 
            // BTLOGIN
            // 
            this.BTLOGIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTLOGIN.Location = new System.Drawing.Point(367, 251);
            this.BTLOGIN.Name = "BTLOGIN";
            this.BTLOGIN.Size = new System.Drawing.Size(117, 39);
            this.BTLOGIN.TabIndex = 4;
            this.BTLOGIN.Text = "Login";
            this.BTLOGIN.UseVisualStyleBackColor = true;
            this.BTLOGIN.Click += new System.EventHandler(this.BTLOGIN_Click);
            // 
            // CBPW
            // 
            this.CBPW.AutoSize = true;
            this.CBPW.Location = new System.Drawing.Point(559, 197);
            this.CBPW.Name = "CBPW";
            this.CBPW.Size = new System.Drawing.Size(94, 17);
            this.CBPW.TabIndex = 5;
            this.CBPW.Text = "แสดง รหัสผ่าน";
            this.CBPW.UseVisualStyleBackColor = true;
            this.CBPW.CheckedChanged += new System.EventHandler(this.CBPW_CheckedChanged);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 450);
            this.Controls.Add(this.CBPW);
            this.Controls.Add(this.BTLOGIN);
            this.Controls.Add(this.TBPASSWORD);
            this.Controls.Add(this.TBUSERNAME);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormLogin";
            this.Text = "FormLogin";
            this.Load += new System.EventHandler(this.FormLogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TBUSERNAME;
        private System.Windows.Forms.TextBox TBPASSWORD;
        private System.Windows.Forms.Button BTLOGIN;
        private System.Windows.Forms.CheckBox CBPW;
    }
}