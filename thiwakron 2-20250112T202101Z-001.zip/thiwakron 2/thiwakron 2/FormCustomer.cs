﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace thiwakron_2
{
    public partial class FormCustomer : Form
    {
        public FormCustomer()
        {
            InitializeComponent();
        }
        DataSet ds = new DataSet();
        private void FormCustomer_Load(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM View_CT";
            SqlDataAdapter da = new SqlDataAdapter(sql, Form1.DATA);
            da.Fill(ds, "ViewCT");
            DTGV_CT.DataSource = ds.Tables["ViewCT"];
            string sql2 = "SELECT * FROM Table_TblSex";
            string sql3 = "SELECT * FROM Table_Tbl_Member";
            da = new SqlDataAdapter(sql2, Form1. DATA);
            da.Fill(ds, "typesex");
            CBSEX.DisplayMember = "NameSex";
            CBSEX.ValueMember = "TypeSex";
            CBSEX.DataSource = ds.Tables["typesex"];
            da = new SqlDataAdapter(sql3, Form1. DATA);
            da.Fill(ds, "Typemember");
            CBMEMBER.DisplayMember = "NameMember";
            CBMEMBER.ValueMember = "TypeMember";
            CBMEMBER.DataSource = ds.Tables["typemember"];
            BTEdit.Enabled = false;
            BTDelete.Enabled = false;
            string sql4 = "SELECT * FROM Table_TblCT";
            da = new SqlDataAdapter(sql4, Form1.DATA);
            da.Fill(ds, "CT");
        }

        private void BTGenID_Click(object sender, EventArgs e)
        {
            string id1 = "SELECT TOP 1 * FROM Table_TblCT ORDER BY IDCT DESC";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(id1, Form1.DATA);
            da.Fill(dt);
            int Topid = Convert.ToInt32(dt.Rows[0]["IDCT"]) + 1;
            LBID.Text = Topid.ToString();
            BTSR.Enabled = false;
        }

        private void Updatedata()
        {
            string sql = "SELECT * FROM Table_TblCT";
            SqlDataAdapter da = new SqlDataAdapter(sql, Form1.DATA);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(ds, "CT");
        }

        private void UpdateView()
        {
            ds.Tables.Remove("ViewCT");
            string sql1 = "SELECT * FROM View_CT";
            SqlDataAdapter  da = new SqlDataAdapter(sql1, Form1.DATA);
            da.Fill(ds, "ViewCT");

            DTGV_CT.DataSource = ds.Tables["ViewCT"];
        }
        private void BTReset_Click(object sender, EventArgs e)
        {
            LBID.Text = "";
            TBName.Text = "";
            TBSname.Text = "";
            TBAddress.Text = "";
            TBTel .Text = "";
            CBSEX.SelectedIndex = 1;
            CBMEMBER.SelectedIndex = 1;
            DTPB.ResetText();
            BTSR.Enabled = true;
        }

        private void BTAdd_Click(object sender, EventArgs e)
        {
            
            string sql = "SELECT * FROM Table_TblCT";
            SqlDataAdapter da = new SqlDataAdapter(sql, Form1.DATA);
            da.Fill(ds, "CT");
            DataRow[] drs = ds.Tables["CT"].Select("IDCT= '" + LBID.Text + "'");
            if (drs.Length == 0)
            {
                DataRow dr = ds.Tables["CT"].NewRow();
                dr["IDCT"] = LBID.Text;
                dr["IDMEMBER"] = LBID.Text;
                dr["NameCT"] = TBName.Text;
                dr["SnameCT"] = TBSname.Text;
                dr["AddressCT"] = TBAddress.Text;
                dr["TelCT"] = TBTel.Text;
                dr["BDCT"] = DTPB.Text;
                dr["TypeSex"] = CBSEX.SelectedValue;
                dr["TypeMember"] = CBMEMBER.SelectedValue;
                ds.Tables["CT"].Rows.Add(dr);
                Updatedata();
                
            }
            else
            {
                MessageBox.Show("เลข ID ซ้ำ", "ERORR");
            }
            UpdateView();
        }

        private void BTDelete_Click(object sender, EventArgs e)
        {
            DialogResult di = MessageBox.Show("ต้องการลบข้อมูลหรือไม่ Yes/ON", "แจ้งเตือนลบข้อมูล", MessageBoxButtons.YesNo);
            if (di == DialogResult.Yes)
            {
                DataRow dr = ds.Tables["CT"].Rows[eindex];
                dr.Delete();
                MessageBox.Show("ลบข้อมูลเสร็จสิ้น");
                Updatedata();
                ds.Tables["CT"].AcceptChanges();
                UpdateView();
            }

        }
        int eindex;
        private void DTGV_CT_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            eindex = e.RowIndex ;
            BTDelete .Enabled =true ;
        }

        private void DTGV_CT_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            eindex = e.RowIndex ;
            BTDelete .Enabled =true ;
        }

        private void DTGV_CT_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DataRow dr = ds.Tables["CT"].Rows[eindex];
            LBID.Text = dr["IDMEMBER"].ToString();
            TBName.Text = dr["NameCT"].ToString();
            TBSname.Text = dr["SnameCT"].ToString();
            TBAddress.Text = dr["AddressCT"].ToString();
            TBTel.Text = dr["TelCT"].ToString();
            DTPB.Text = dr["BDCT"].ToString();
            CBSEX.SelectedValue = dr["TypeSex"].ToString();
            CBMEMBER.SelectedValue = dr["TypeMember"].ToString();
            BTAdd.Enabled = false;
            BTDelete.Enabled = false;
            BTEdit.Enabled = true;
        }

        private void BTEdit_Click(object sender, EventArgs e)
        {
            DataRow dr = ds.Tables["CT"].Rows[eindex];
            dr["IDMEMBER"] = LBID.Text;
            dr["NameCT"] = TBName.Text;
            dr["SnameCT"] = TBSname.Text;
            dr["AddressCT"] = TBAddress.Text;
            dr["TelCT"] = TBTel.Text;
            dr["BDCT"] = DTPB.Text;
            dr["TypeSex"] = CBSEX.SelectedValue;
            dr["TypeMember"] = CBMEMBER.SelectedValue;
            Updatedata();
            UpdateView();
            BTAdd.Enabled = false;
            BTDelete.Enabled = true ;
            BTEdit.Enabled = true;
        }

        private void TBSR_TextChanged(object sender, EventArgs e)
        {

        }

        private void BTSR_Click(object sender, EventArgs e)
        {
            if (ds.Tables.Contains("SR"))
            {
                ds.Tables.Remove("SR");
            }
            string sql = "SELECT* FROM View_CT WHERE IDMEMBER LIKE '%" + TBSR.Text + "%'OR NameCT LIKE '%" + TBSR.Text + "%'OR TelCT LIKE'%" + TBSR.Text +"%'";
            SqlDataAdapter da = new SqlDataAdapter(sql, Form1. DATA);
            da.Fill(ds,"SR");
            DTGV_CT.DataSource = ds.Tables["SR"];
        }

    }
}
