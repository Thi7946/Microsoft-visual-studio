﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace thiwakron_2
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void BTLOGIN_Click(object sender, EventArgs e)
        {
            string sql = string.Format("SELECT * FROM TBL_ADMIN WHERE USERNAME='{0}' AND PASSWORD='{1}'", TBUSERNAME.Text, TBPASSWORD.Text);
            SqlDataAdapter da = new SqlDataAdapter(sql,  Form1.DATA);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                String name =dt.Rows [0]["USERNAME"].ToString();
                MessageBox .Show ("ยินดีต้อนรับ คุณ"+name,"Login สำเร้จ");
                Form1.Loginstat = "1";
                this.Close();
            }
            else
            {
                MessageBox.Show("USER หรือ PASSWORD ไม่ถูกต้อง", "ERROR");
            }
        }

        private void CBPW_CheckedChanged(object sender, EventArgs e)
        {
            if (CBPW .Checked ==true )
            {
                TBPASSWORD.PasswordChar ='\0';
            }
            else
            {
                TBPASSWORD.PasswordChar = '*';
            }
        }
    }
}
