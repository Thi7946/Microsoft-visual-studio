<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }
        .result-box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 50%;
            margin: 0 auto;
        }
        h3 {
            color: #0066cc;
        }
    </style>
</head>
<body>

<div class="result-box">
    <h3>Form Submission Result</h3>
    <?php
    $prefix = $_POST['prefix'];
    $fullname = $_POST['fullname'];
    $gender = $_POST['gender'];
    $devices = isset($_POST['device']) ? implode(", ", $_POST['device']) : "None";
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password === $confirm_password) {
        echo "คำนำหน้าชื่อ: $prefix<br>";
        echo "ชื่อ-นามสกุล: $fullname<br>";
        echo "เพศ: $gender<br>";
        echo "อุปกรณ์ที่ใช้มากที่สุด: $devices<br>";
        echo "Email: $email<br>";
        echo "Username: $username<br>";
    } else {
        echo "Password และ Confirm Password ไม่ตรงกัน!";
    }
    ?>
</div>

</body>
</html>
