<?php
session_start();

$hostname_surachet = "localhost";
$database_surachet = "u299560388_651237";
$username_surachet = "u299560388_651237";
$password_surachet = "EL5811Lt";
$surachet = mysqli_connect($hostname_surachet, $username_surachet, $password_surachet, $database_surachet);

if (!$surachet) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}

function executeQuery($sql) {
    global $surachet;
    return mysqli_query($surachet, $sql);
}

// สำหรับจัดการการเพิ่ม/แก้ไขนักศึกษา
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sid = $_POST['SID'];
    $name = $_POST['StudentName'];
    $lastname = $_POST['StudentLastname'];
    $age = $_POST['Age'];
    $year = $_POST['Year'];
    $address = $_POST['Address'];
    $telephone = $_POST['Telephone'];
    $depID = $_POST['DepID'];
    $provinceID = $_POST['ProvinceID']; // รับข้อมูล ProvinceID
    $hobbyIDs = $_POST['hobbyID']; // รับข้อมูลหลาย hobbyID ที่ถูกส่งมาจากฟอร์ม

    if (empty($sid)) {
        // เพิ่มข้อมูลนักศึกษาใหม่
        $sql = "INSERT INTO tbl_student (StudentName, StudentLastname, Age, Year, Address, Telephone, DepID, ProvinceID)
                VALUES ('$name', '$lastname', '$age', '$year', '$address', '$telephone', '$depID', '$provinceID')";
        executeQuery($sql);
        $sid = mysqli_insert_id($surachet); // รับ SID ที่เพิ่งสร้างขึ้น
    } else {
        // แก้ไขข้อมูลนักศึกษา
        $sql = "UPDATE tbl_student SET 
                StudentName='$name', StudentLastname='$lastname', Age='$age', Year='$year', 
                Address='$address', Telephone='$telephone', DepID='$depID', ProvinceID='$provinceID' WHERE SID='$sid'";
        executeQuery($sql);
    }

    // จัดการงานอดิเรก
    // ลบงานอดิเรกเก่าที่มีอยู่
    $sql = "DELETE FROM tbl_studenthobby WHERE SID='$sid'";
    executeQuery($sql);

    // เพิ่มงานอดิเรกใหม่
    foreach ($hobbyIDs as $hobbyID) {
        $sql = "INSERT INTO tbl_studenthobby (SID, HobbyID) VALUES ('$sid', '$hobbyID')";
        executeQuery($sql);
    }

    $_SESSION['message'] = 'บันทึกข้อมูลสำเร็จ!'; // เก็บข้อความในเซสชัน
    header("Location: index.php"); // เปลี่ยนเป็น index.php
    exit(); // ป้องกันการส่งข้อมูลซ้ำ
}

// จัดการลบข้อมูลนักศึกษา
if (isset($_GET['delete'])) {
    $sid = $_GET['delete'];
    if (is_numeric($sid)) {
        // ลบข้อมูลนักศึกษา
        $sql = "DELETE FROM tbl_student WHERE SID='$sid'";
        executeQuery($sql);
        
        // ลบงานอดิเรกที่เกี่ยวข้อง
        $sql = "DELETE FROM tbl_studenthobby WHERE SID='$sid'";
        executeQuery($sql);
        
        $_SESSION['message'] = 'ลบข้อมูลนักศึกษาเรียบร้อยแล้ว!';
        header("Location: index.php"); // เปลี่ยนเป็น index.php
        exit();
    }
}

// ดึงข้อมูลนักศึกษาและข้อมูลแผนกที่เกี่ยวข้องเมื่อแก้ไข
$student = null;
if (isset($_GET['edit'])) {
    $sid = $_GET['edit'];
    if (!is_numeric($sid)) {
        die("รหัสนักศึกษาไม่ถูกต้อง");
    }

    $sql = "SELECT s.*, d.Department, p.ProvinceName FROM tbl_student s 
            LEFT JOIN tbl_department d ON s.DepID = d.DepID 
            LEFT JOIN tbl_province p ON s.ProvinceID = p.ProvinceID 
            WHERE s.SID='$sid'";
    $result = executeQuery($sql);
    
    if ($result) {
        $student = mysqli_fetch_assoc($result);
        if (!$student) {
            echo "ไม่พบข้อมูลนักศึกษา";
        }
    } else {
        echo "ข้อผิดพลาดในการดึงข้อมูล: " . mysqli_error($surachet);
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบจัดการนักศึกษา</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    <style>
        .select2-container--default .select2-selection--multiple {
            height: auto; /* ปรับความสูงของ Select2 */
        }
        .select2-selection__choice {
            margin: 2px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mt-4">จัดการนักศึกษา</h2>

    <!-- แสดงข้อความเมื่อมีการบันทึก -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success">
            <?php 
                echo $_SESSION['message']; 
                unset($_SESSION['message']); // ลบข้อความจากเซสชัน
            ?>
        </div>
    <?php endif; ?>

    <!-- ฟอร์มสำหรับเพิ่ม/แก้ไขนักศึกษา -->
    <form action="" method="POST">
        <div class="form-group">
            <label for="StudentName">ชื่อ</label>
            <input type="text" class="form-control" id="StudentName" name="StudentName" value="<?php echo isset($student['StudentName']) ? htmlspecialchars($student['StudentName']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="StudentLastname">นามสกุล</label>
            <input type="text" class="form-control" id="StudentLastname" name="StudentLastname" value="<?php echo isset($student['StudentLastname']) ? htmlspecialchars($student['StudentLastname']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="Age">อายุ</label>
            <input type="number" class="form-control" id="Age" name="Age" value="<?php echo isset($student['Age']) ? htmlspecialchars($student['Age']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="Year">ปีการศึกษา</label>
            <input type="number" class="form-control" id="Year" name="Year" value="<?php echo isset($student['Year']) ? htmlspecialchars($student['Year']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="Address">ที่อยู่</label>
            <textarea class="form-control" id="Address" name="Address" required><?php echo isset($student['Address']) ? htmlspecialchars($student['Address']) : ''; ?></textarea>
        </div>
        <div class="form-group">
            <label for="Telephone">เบอร์โทรศัพท์</label>
            <input type="text" class="form-control" id="Telephone" name="Telephone" value="<?php echo isset($student['Telephone']) ? htmlspecialchars($student['Telephone']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="DepID">แผนก</label>
            <select class="form-control" id="DepID" name="DepID" required>
                <option value="">เลือกแผนก</option>
                <?php
                // ดึงข้อมูลแผนกจากฐานข้อมูล
                $sql_department = "SELECT * FROM tbl_department";
                $result_department = executeQuery($sql_department);
                while ($department = mysqli_fetch_assoc($result_department)) {
                    $selected = (isset($student['DepID']) && $department['DepID'] == $student['DepID']) ? 'selected' : '';
                    echo "<option value='{$department['DepID']}' $selected>{$department['Department']}</option>";
                }
                ?>
            </select>
        </div>
        
        <!-- เพิ่ม combobox สำหรับจังหวัด -->
        <div class="form-group">
            <label for="ProvinceID">จังหวัด</label>
            <select class="form-control" id="ProvinceID" name="ProvinceID" required>
                <option value="">เลือกจังหวัด</option>
                <?php
                // ดึงข้อมูลจังหวัดจากฐานข้อมูล
                $sql_province = "SELECT * FROM tbl_province";
                $result_province = executeQuery($sql_province);
                while ($province = mysqli_fetch_assoc($result_province)) {
                    $selected = (isset($student['ProvinceID']) && $province['ProvinceID'] == $student['ProvinceID']) ? 'selected' : '';
                    echo "<option value='{$province['ProvinceID']}' $selected>{$province['ProvinceName']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="hobbyID">งานอดิเรก</label>
            <select class="form-control" id="hobbyID" name="hobbyID[]" multiple="multiple" required>
                <?php
                // ดึงข้อมูลงานอดิเรกจากฐานข้อมูล
                $sql_hobby = "SELECT * FROM tbl_hobby";
                $result_hobby = executeQuery($sql_hobby);
                $selected_hobbies = [];
                
                // ถ้าเป็นการแก้ไข ให้ดึงงานอดิเรกที่เลือกไว้
                if ($student) {
                    $sql_selected_hobbies = "SELECT HobbyID FROM tbl_studenthobby WHERE SID='{$student['SID']}'";
                    $result_selected_hobbies = executeQuery($sql_selected_hobbies);
                    while ($selected_hobby = mysqli_fetch_assoc($result_selected_hobbies)) {
                        $selected_hobbies[] = $selected_hobby['HobbyID'];
                    }
                }

                // แสดงรายการงานอดิเรกใน combobox
                while ($hobby = mysqli_fetch_assoc($result_hobby)) {
                    $selected = in_array($hobby['HobbyID'], $selected_hobbies) ? 'selected' : '';
                    echo "<option value='{$hobby['HobbyID']}' $selected>{$hobby['HobbyName']}</option>";
                }
                ?>
            </select>
            <small class="form-text text-muted">กด Ctrl เพื่อเลือกงานอดิเรกหลายรายการ</small>
        </div>

        <input type="hidden" name="SID" value="<?php echo isset($student['SID']) ? htmlspecialchars($student['SID']) : ''; ?>">
        <button type="submit" class="btn btn-primary" name="SaveStudent">บันทึก</button>
    </form>

    <hr>

<!-- แสดงรายชื่อนักศึกษา -->
<h4>รายชื่อนักศึกษา</h4>
<table class="table table-bordered">
    <thead>
    <tr>
        <th>รหัส</th>
        <th>ชื่อ</th>
        <th>นามสกุล</th>
        <th>งานอดิเรก</th> <!-- เพิ่มคอลัมน์งานอดิเรก -->
        <th>แผนก</th> <!-- เพิ่มคอลัมน์แผนก -->
        <th>การจัดการ</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $sql = "SELECT s.SID, s.StudentName, s.StudentLastname, d.Department, GROUP_CONCAT(h.HobbyName SEPARATOR ', ') AS Hobbies 
            FROM tbl_student s 
            LEFT JOIN tbl_department d ON s.DepID = d.DepID 
            LEFT JOIN tbl_studenthobby sh ON s.SID = sh.SID 
            LEFT JOIN tbl_hobby h ON sh.HobbyID = h.HobbyID 
            GROUP BY s.SID"; // ดึงข้อมูลนักศึกษาและงานอดิเรก
    $result = executeQuery($sql);
    while ($student = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>{$student['SID']}</td>";
        echo "<td>{$student['StudentName']}</td>";
        echo "<td>{$student['StudentLastname']}</td>";
        echo "<td>{$student['Hobbies']}</td>"; // แสดงงานอดิเรก
        echo "<td>{$student['Department']}</td>"; // แสดงแผนก
        echo "<td>
                <a href='?edit={$student['SID']}' class='btn btn-warning'>แก้ไข</a>
                <a href='?delete={$student['SID']}' class='btn btn-danger' onclick=\"return confirm('คุณแน่ใจว่าต้องการลบข้อมูลนี้?');\">ลบ</a>
              </td>";
        echo "</tr>";
    }
    ?>
    </tbody>
</table>


<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('#hobbyID').select2({
            placeholder: "เลือกงานอดิเรก",
            allowClear: true,
            width: '100%' // ปรับความกว้างของ Select2
        });
    });
</script>
</body>
</html>
