<?php
session_start();

$hostname_surachet = "localhost";
$database_surachet = "u299560388_651237";
$username_surachet = "u299560388_651237";
$password_surachet = "EL5811Lt";
$surachet = mysqli_connect($hostname_surachet, $username_surachet, $password_surachet, $database_surachet);

if (!$surachet) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST["InsertNewStudent"] == "Yes") {
    $prefix = $_POST['initial'];
    $studentName = $_POST['name'];
    $studentLastname = $_POST['lastname'];
    $age = $_POST['age'];
    $address = $_POST['address'];
    $telephone = $_POST['telephone'];
    $depID = $_POST['DepID']; // แก้ไขเป็น DepID
    $provinceID = $_POST['province'];

    // ค้นหาหมายเลข SID ที่ว่าง 
    $sql = "SELECT MAX(SID) as maxSID FROM tbl_student";
    $result = mysqli_query($surachet, $sql);
    $row = mysqli_fetch_assoc($result);
    $newSID = $row['maxSID'] + 1; // เพิ่ม 1 ไปยังหมายเลขสูงสุดที่มีอยู่

    // ตอนนี้ใช้ $newSID เป็น SID ใหม่ในการเพิ่มข้อมูล
    $sql = "INSERT INTO tbl_student (SID, prefix, StudentName, StudentLastname, Age, Address, Telephone, DepID, ProvinceID) 
            VALUES ('$newSID', '$prefix', '$studentName', '$studentLastname', '$age', '$address', '$telephone', '$depID', '$provinceID')";
    
    // Execute query
    if (mysqli_query($surachet, $sql)) {
        // จัดการงานอดิเรก
        if (!empty($_POST['hobbyID'])) {
            foreach ($_POST['hobbyID'] as $hobbyID) {
                $sql_hobby = "INSERT INTO tbl_studenthobby (SID, HobbyID) VALUES ('$newSID', '$hobbyID')";
                mysqli_query($surachet, $sql_hobby);
            }
        }

        header("location: index.php");
        exit();
    } else {
        die("Error: " . mysqli_error($surachet));
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>เพิ่มนักศึกษาใหม่</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
<center>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
        <fieldset>
            <legend><font color="#0000FF"><b>เพิ่มนักศึกษาใหม่</b></font></legend>
            <table width="60%" border="0" cellpadding="5" cellspacing="0">
                <tr bgcolor="#0066ff">
                    <td colspan="2" align="center"><font color="white"><b>ประวัตินักศึกษา</b></font></td>
                </tr>
                <tr>
                    <td>คำนำหน้า</td>
                    <td align="left">
                        <input type="radio" name="initial" value="นาย" checked>นาย
                        <input type="radio" name="initial" value="นางสาว">นางสาว
                    </td>
                </tr>
                <tr>
                    <td>ชื่อ</td>
                    <td align="left"><input type="text" name="name" size="50" maxlength="50" required></td>
                </tr>
                <tr>
                    <td>นามสกุล</td>
                    <td align="left"><input type="text" name="lastname" size="50" maxlength="50" required></td>
                </tr>
                <tr>
                    <td>อายุ</td>
                    <td align="left"><input type="number" name="age" min="1" required></td>
                </tr>
                <tr>
                    <td>ที่อยู่</td>
                    <td align="left"><input type="text" name="address" size="50" maxlength="100" required></td>
                </tr>
                <tr>
                    <td>โทรศัพท์</td>
                    <td align="left"><input type="text" name="telephone" size="50" maxlength="15" required></td>
                </tr>
                <tr>
                    <td>แผนก</td>
                    <td>
                        <select class="form-control" id="DepID" name="DepID" required>
                            <option value="">เลือกแผนก</option>
                            <?php
                            // ดึงข้อมูลแผนกจากฐานข้อมูล
                            $sql_department = "SELECT * FROM tbl_department";
                            $result_department = mysqli_query($surachet, $sql_department);
                            while ($department = mysqli_fetch_assoc($result_department)) {
                                echo "<option value='{$department['DepID']}'>{$department['Department']}</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>จังหวัด</td>
                    <td>
                        <select name="province" required>
                            <option value="">เลือกจังหวัด</option>
                            <?php
                            $sql = "SELECT * FROM tbl_province";
                            $result = mysqli_query($surachet, $sql);
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='{$row['ProvinceID']}'>{$row['ProvinceName']}</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>งานอดิเรก</td>
                    <td>
                        <?php
                        // ดึงข้อมูลงานอดิเรก
                        $sql_hobby = "SELECT * FROM tbl_hobby";
                        $result_hobby = mysqli_query($surachet, $sql_hobby);
                        while ($hobby = mysqli_fetch_assoc($result_hobby)) {
                            echo "<input type='checkbox' name='hobbyID[]' value='{$hobby['HobbyID']}'> {$hobby['HobbyName']}<br>";
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="hidden" name="InsertNewStudent" value="Yes">
                        <input type="submit" name="submit" value="เพิ่ม">
                        <input type="reset" name="reset" value="Reset">
                    </td>
                </tr>
            </table>
            <hr width="60%" color="red">
        </fieldset>
    </form>
</center>
</body>
</html>
