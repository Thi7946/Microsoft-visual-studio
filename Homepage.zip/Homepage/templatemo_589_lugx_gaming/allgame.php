<?php
session_start();
include 'connect.php'; // เชื่อมต่อฐานข้อมูล

// ฟังก์ชันสำหรับรัน SQL
function executeQuery($sql) {
    global $conn;
    return mysqli_query($conn, $sql);
}

// ตรวจสอบว่ามีการส่ง game_id ผ่านตัวแปร GET หรือไม่เพื่อลบข้อมูล
if (isset($_GET['delete'])) {
    $game_id = $_GET['delete'];
    
    // ตรวจสอบว่า game_id มีอยู่ในฐานข้อมูลหรือไม่ก่อนที่จะลบ
    $sql = "DELETE FROM games WHERE game_id='$game_id'";
    if (executeQuery($sql)) {
        $_SESSION['message'] = 'ลบข้อมูลเกมสำเร็จ!';
    } else {
        $_SESSION['message'] = 'เกิดข้อผิดพลาดในการลบข้อมูล!';
    }
    header('Location:allgame.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบจัดการเกม</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        .game-image {
            width: 100px; /* กำหนดขนาดของรูปภาพเกม */
            height: auto; /* ให้คงสัดส่วนของรูปภาพ */
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mt-4">จัดการเกม</h2>

    <a href="addgame.php" class="btn btn-primary mb-3">เพิ่มเกม</a>

    <!-- แสดงข้อความเมื่อมีการลบหรือบันทึกสำเร็จ -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success">
            <?= $_SESSION['message'] ?>
            <?php unset($_SESSION['message']); ?>
        </div>
    <?php endif; ?>

    <!-- Display game list -->
    <h4>รายชื่อเกม</h4>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>รูปภาพ</th>
            <th>รหัสเกม</th>
            <th>ชื่อเกม</th>
            <th>วันวางจำหน่าย</th>
            <th>ผู้พัฒนา</th>
            <th>ประเภท</th>
            <th>คำอธิบาย</th>
            <th>การจัดการ</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // ดึงข้อมูลจากตาราง games ร่วมกับตาราง game_images และ game_categories
        $sql = "SELECT g.game_id, g.game_name, g.release_date, g.developer, c.category_name, 
                       g.description, gi.image
                FROM games g
                LEFT JOIN game_categories c ON g.category_id = c.category_id
                LEFT JOIN game_images gi ON g.image_game_id = gi.image_game_id";
        $result = executeQuery($sql);

        // แสดงข้อมูลในตาราง
        while ($game = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            // แสดงรูปภาพ
            echo "<td><img src='" . htmlspecialchars($game['image']) . "' alt='Game Image' class='game-image'></td>";
            echo "<td>{$game['game_id']}</td>";
            echo "<td>{$game['game_name']}</td>";
            echo "<td>{$game['release_date']}</td>";
            echo "<td>{$game['developer']}</td>";
            echo "<td>{$game['category_name']}</td>";
            echo "<td>{$game['description']}</td>";
            echo "<td>
                    <a href='gameedit.php?edit={$game['game_id']}' class='btn btn-warning'>แก้ไข</a>
                    <a href='allgame.php?delete={$game['game_id']}' class='btn btn-danger' onclick=\"return confirm('คุณแน่ใจว่าต้องการลบข้อมูลเกมนี้?');\">ลบ</a>
                  </td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
