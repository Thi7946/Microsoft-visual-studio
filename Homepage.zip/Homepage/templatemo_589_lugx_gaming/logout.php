<?php
session_start(); // เริ่มเซสชัน
session_destroy(); // ทำลายเซสชัน
header("Location: index.php"); // เปลี่ยนเส้นทางไปยังหน้า Login
exit();
?>