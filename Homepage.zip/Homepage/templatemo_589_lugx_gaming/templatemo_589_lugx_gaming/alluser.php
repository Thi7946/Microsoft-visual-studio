<?php  
session_start();
include 'connect.php';

// Function to execute SQL queries
function executeQuery($sql) {
    global $conn; 
    return mysqli_query($conn, $sql); 
}

// Handle delete request
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    // Delete favorites first
    $deletefavoritesSQL = "DELETE FROM favorites WHERE id_account='$id'";
    executeQuery($deletefavoritesSQL);

    // Delete account
    $sql = "DELETE FROM account WHERE id_account='$id'";
    executeQuery($sql);

    // Show success message
    echo "<script>alert('ลบข้อมูลอีเมลเรียบร้อยแล้ว');</script>";
    header("Location: alluser.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบจัดการอีเมล</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        .profile-image {
            width: 50px; /* กำหนดขนาดของรูปภาพ */
            height: 50px; /* กำหนดขนาดของรูปภาพ */
            border-radius: 50%; /* ทำให้รูปภาพเป็นวงกลม */
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mt-4">จัดการอีเมล</h2>

    <a href="stomeemail.php" class="btn btn-primary mb-3">เพิ่มอีเมล</a>

    <!-- Display account list -->
    <h4>รายชื่อเมล</h4>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>รูปภาพ</th>
            <th>รหัส</th>
            <th>ชื่ออีเมล</th>
            <th>Email</th>
            <th>Password</th>
            <th>การจัดการ</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // ดึงข้อมูลจากตาราง account ร่วมกับตาราง account_images
        $sql = "SELECT a.id_account, a.username_account, a.email_account, a.password_account, ai.image_url 
                FROM account a 
                LEFT JOIN account_images ai ON a.image_account_id = ai.image_account_id";
        $result = executeQuery($sql);

        // แสดงข้อมูลในตาราง
        while ($account = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            // แสดงรูปภาพ
            echo "<td><img src='" . htmlspecialchars($account['image_url']) . "' alt='Profile Image' class='profile-image'></td>";
            echo "<td>{$account['id_account']}</td>";
            echo "<td>{$account['username_account']}</td>";
            echo "<td>{$account['email_account']}</td>";
            echo "<td>{$account['password_account']}</td>"; // แสดงรหัสผ่าน (ควรพิจารณาความปลอดภัย)
            echo "<td>
                    <a href='edituseremail.php?edit={$account['id_account']}' class='btn btn-warning'>แก้ไข</a>
                    <a href='?delete={$account['id_account']}' class='btn btn-danger' onclick=\"return confirm('คุณแน่ใจว่าต้องการลบข้อมูลอีเมลนี้?');\">ลบ</a>
                  </td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
