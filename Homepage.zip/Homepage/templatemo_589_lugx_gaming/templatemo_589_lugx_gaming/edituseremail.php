<?php        
session_start();
include 'connect.php'; // เชื่อมต่อฐานข้อมูล

// Function to execute SQL queries
function executeQuery($sql) {
    global $conn;
    $result = mysqli_query($conn, $sql);
    if (!$result) {
        die('ข้อผิดพลาดในการดำเนินการ: ' . mysqli_error($conn));
    }
    return $result;
}

// ฟังก์ชันสำหรับอัปโหลดไฟล์ภาพ
function uploadImage($file) {
    global $conn; // ใช้การเชื่อมต่อฐานข้อมูลจากไฟล์ connect.php
    $targetDir = "assets/profile/"; // โฟลเดอร์ที่เก็บรูปภาพ
    $targetFile = $targetDir . basename($file["name"]);
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    
    // ตรวจสอบว่าเป็นภาพหรือไม่
    $check = getimagesize($file["tmp_name"]);
    if($check === false) {
        return "ไฟล์ไม่ใช่รูปภาพ.";
    }

    // ตรวจสอบขนาดไฟล์
    if ($file["size"] > 500000) { // จำกัดขนาดไฟล์ที่ 500KB
        return "ขนาดไฟล์มากเกินไป.";
    }

    // อนุญาตให้เฉพาะบางประเภทไฟล์
    if(!in_array($imageFileType, ['jpg', 'png', 'jpeg', 'gif'])) {
        return "ขออภัย อนุญาตให้ใช้เฉพาะไฟล์ JPG, JPEG, PNG & GIF.";
    }

    // อัปโหลดไฟล์
    if (move_uploaded_file($file["tmp_name"], $targetFile)) {
        // บันทึกข้อมูลรูปภาพในฐานข้อมูล
        $imageName = basename($file["name"]);
        $imageUrl = $targetFile;
        $createdAt = date('Y-m-d H:i:s');
        
        $sql = "INSERT INTO account_images (image_name, image_url, created_at) VALUES ('$imageName', '$imageUrl', '$createdAt')";
        if (executeQuery($sql)) {
            return mysqli_insert_id($conn); // คืนค่า image_account_id ที่เพิ่งถูกเพิ่ม
        } else {
            return "เกิดข้อผิดพลาดในการบันทึกข้อมูลรูปภาพ: " . mysqli_error($conn);
        }
    } else {
        return "เกิดข้อผิดพลาดในการอัปโหลดไฟล์: " . print_r(error_get_last(), true);
    }
}

// เมื่อมีการอัปโหลดไฟล์ภาพในฟอร์ม
$imageId = null; // ตัวแปรสำหรับเก็บ image_account_id
if (isset($_FILES['image_account']) && $_FILES['image_account']['size'] > 0) {
    $imageId = uploadImage($_FILES['image_account']); // เรียกฟังก์ชันอัปโหลดไฟล์
}

// จัดการการบันทึกข้อมูล
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape ค่าข้อมูลเพื่อลดปัญหา SQL Injection
    $id = mysqli_real_escape_string($conn, $_POST['id_account']);
    $name = mysqli_real_escape_string($conn, $_POST['username_account']);
    $email = mysqli_real_escape_string($conn, $_POST['email_account']);
    $password = mysqli_real_escape_string($conn, $_POST['password_account']);
    
    // ใช้ image_account_id จากการอัปโหลดหรือตาม URL ที่กรอก
    $imagePath = null;
    if ($imageId && is_numeric($imageId)) {
        // ถ้ามีการอัปโหลดภาพใหม่
        $imagePath = $imageId; // ใช้ image_account_id จากการอัปโหลด
    } elseif (isset($_POST['image_account_url']) && !empty($_POST['image_account_url'])) {
        $imageUrl = mysqli_real_escape_string($conn, $_POST['image_account_url']);
        
        // ตรวจสอบว่า URL รูปภาพถูกต้องหรือไม่
        $sql = "INSERT INTO account_images (image_name, image_url, created_at) VALUES ('URL รูปภาพ', '$imageUrl', NOW())";
        if (executeQuery($sql)) {
            $imagePath = mysqli_insert_id($conn); // รับ image_account_id จากการเพิ่ม URL
        }
    }

    // ตรวจสอบและลบรูปภาพเก่า
    if (!empty($id)) {
        // รับข้อมูลเก่าจากฐานข้อมูล
        $sql = "SELECT image_account_id FROM account WHERE id_account='$id'";
        $result = executeQuery($sql);
        $oldImage = mysqli_fetch_assoc($result);

        if ($oldImage && isset($oldImage['image_account_id'])) {
            // ลบข้อมูลรูปภาพเก่าในตาราง account_images
            $sqlDeleteImage = "DELETE FROM account_images WHERE image_account_id='" . $oldImage['image_account_id'] . "'";
            executeQuery($sqlDeleteImage);
        }
    }

    // ถ้ารูปภาพถูกอัปโหลดสำเร็จ
    if (empty($id)) {
        // เพิ่มข้อมูลใหม่
        $sql = "INSERT INTO account (username_account, email_account, password_account, image_account_id)
                VALUES ('$name', '$email', '$password', " . ($imagePath ? $imagePath : 'NULL') . ")";
        if (executeQuery($sql)) {
            $_SESSION['message'] = 'เพิ่มข้อมูลสำเร็จ!';
        } else {
            $_SESSION['message'] = 'เกิดข้อผิดพลาดในการเพิ่มข้อมูล!';
        }
    } else {
        // แก้ไขข้อมูล
        $sql = "UPDATE account SET 
                username_account='$name', email_account='$email', password_account='$password', image_account_id=" . ($imagePath ? $imagePath : 'NULL') . "
                WHERE id_account='$id'";
        if (executeQuery($sql)) {
            $_SESSION['message'] = 'แก้ไขข้อมูลสำเร็จ!';
        } else {
            $_SESSION['message'] = 'เกิดข้อผิดพลาดในการแก้ไขข้อมูล!';
        }
    }

    header("Location: alluser.php");
    exit();
}

// จัดการลบข้อมูล
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    if (is_numeric($id)) {
        // ลบข้อมูลในตาราง account
        $sql = "DELETE FROM account WHERE id_account='$id'";
        if (executeQuery($sql)) {
            $_SESSION['message'] = 'ลบข้อมูลเรียบร้อยแล้ว!';
        } else {
            $_SESSION['message'] = 'เกิดข้อผิดพลาดในการลบข้อมูล!';
        }

        header("Location: alluser.php");
        exit();
    }
}

// ดึงข้อมูลเมื่อแก้ไข
$student = null;
if (isset($_GET['edit'])) {
    $id = mysqli_real_escape_string($conn, $_GET['edit']);
    if (!is_numeric($id)) {
        die("รหัสไม่ถูกต้อง");
    }

    $sql = "SELECT * FROM account WHERE id_account='$id'";
    $result = executeQuery($sql);
    
    if ($result) {
        $student = mysqli_fetch_assoc($result);
        if (!$student) {
            echo "ไม่พบข้อมูล";
        }
    } else {
        echo "ข้อผิดพลาดในการดึงข้อมูล: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบจัดการอีเมล</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        .profile-image {
            width: 100px; /* ขนาดรูปภาพ */
            height: 100px;
            border-radius: 50%;
        }
        .image-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mt-4">จัดการอีเมล</h2>

    <!-- แสดงข้อความเมื่อบันทึกข้อมูลสำเร็จ -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-success">
            <?php 
                echo $_SESSION['message']; 
                unset($_SESSION['message']);
            ?>
        </div>
    <?php endif; ?>

    <!-- ฟอร์มเพิ่ม/แก้ไขอีเมล -->
    <form action="" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id_account" value="<?php echo isset($student['id_account']) ? htmlspecialchars($student['id_account']) : ''; ?>">
        <div class="form-group">
            <label for="username_account">ชื่อ</label>
            <input type="text" class="form-control" id="username_account" name="username_account" value="<?php echo isset($student['username_account']) ? htmlspecialchars($student['username_account']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="email_account">อีเมล</label>
            <input type="email" class="form-control" id="email_account" name="email_account" value="<?php echo isset($student['email_account']) ? htmlspecialchars($student['email_account']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="password_account">รหัสผ่าน</label>
            <input type="text" class="form-control" id="password_account" name="password_account" value="<?php echo isset($student['password_account']) ? htmlspecialchars($student['password_account']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="image_account">อัปโหลดรูปภาพ</label>
            <input type="file" class="form-control" id="image_account" name="image_account">
        </div>
        <div class="form-group">
            <label for="image_account_url">URL รูปภาพ (ถ้าไม่อัปโหลด)</label>
            <input type="text" class="form-control" id="image_account_url" name="image_account_url" placeholder="กรุณากรอก URL ถ้าไม่อัปโหลดรูป">
        </div>
        <button type="submit" class="btn btn-primary">บันทึก</button>
    </form>

    <!-- แสดงรายการอีเมล -->
    <h3 class="mt-4">รายการอีเมล</h3>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>ชื่อ</th>
                <th>Email</th>
                <th>Password</th>
                <th>รูปภาพ</th>
                <th>การจัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT a.id_account, a.username_account, a.email_account,a.password_account, ai.image_url
                    FROM account a
                    LEFT JOIN account_images ai ON a.image_account_id = ai.image_account_id";
            $result = executeQuery($sql);
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($row['id_account']) . '</td>';
                echo '<td>' . htmlspecialchars($row['username_account']) . '</td>';
                echo '<td>' . htmlspecialchars($row['email_account']) . '</td>';
                echo '<td>' . htmlspecialchars($row['password_account']) . '</td>';
                echo '<td>';
                echo '<div class="image-container">';
                if ($row['image_url']) {
                    echo '<img src="' . htmlspecialchars($row['image_url']) . '" class="profile-image" alt="Profile Image">';
                } else {
                    echo 'ไม่มีรูปภาพ';
                }
                echo '</div>';
                echo '</td>';
                echo '<td>
                        <a href="?edit=' . htmlspecialchars($row['id_account']) . '" class="btn btn-warning">แก้ไข</a>
                        <a href="?delete=' . htmlspecialchars($row['id_account']) . '" class="btn btn-danger" onclick="return confirm(\'แน่ใจหรือไม่ที่จะลบ?\');">ลบ</a>
                      </td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>
