<?php
session_start();
session_unset(); // ลบค่าทั้งหมดใน session
session_destroy(); // ทำลาย session
header("Location: Login.php"); // เปลี่ยนเส้นทางไปยังหน้า Login
exit();
?>