<?php
session_start(); // เริ่มต้น session
// เชื่อมต่อฐานข้อมูล
$servername = "localhost";
$username = "u299560388_651207";
$password = "PB7712Qh";
$dbname = "u299560388_651207";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// ตรวจสอบว่าผู้ใช้ล็อกอินแล้วหรือไม่
if (!isset($_SESSION['id_account'])) {
    die("You must be logged in to view this page.");
}

$id_account = $_SESSION['id_account'];

// ลบเกมออกจากรายการชื่นชอบ
if (isset($_POST['remove_from_favorite'])) {
    $game_id = $_POST['game_id'];
    $stmt = $conn->prepare("DELETE FROM favorites WHERE id_account = :id_account AND game_id = :game_id");
    $stmt->execute(['id_account' => $id_account, 'game_id' => $game_id]);

    // รีเฟรชหน้าเพื่ออัปเดตข้อมูลใหม่
    header("Location: " . $_SERVER['PHP_SELF']);
    exit(); // เพื่อหยุดการดำเนินการเพิ่มเติมหลังจากรีเฟรชหน้า
}

// ดึงรายการเกมชื่นชอบของผู้ใช้
$stmt = $conn->prepare("SELECT g.game_id, g.game_name, c.category_name, i.image 
                        FROM games g 
                        JOIN game_categories c ON g.category_id = c.category_id
                        JOIN game_images i ON g.image_game_id = i.image_game_id
                        JOIN favorites f ON g.game_id = f.game_id
                        WHERE f.id_account = :id_account");
$stmt->execute(['id_account' => $id_account]);
$favorites = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Favorite Games</title>
</head>
<body>
    <h3>Your Favorite Games</h3>

    <div class="favorite-games">
        <?php if (!empty($favorites)) { ?>
            <?php foreach ($favorites as $game) { ?>
                <div class="game-item">
                    <img src="<?php echo $game['image']; ?>" alt="<?php echo $game['game_name']; ?>">
                    <h4><?php echo $game['game_name']; ?></h4>
                    <p><?php echo $game['category_name']; ?></p>
                    <form method="POST">
                        <input type="hidden" name="game_id" value="<?php echo $game['game_id']; ?>">
                        <button type="submit" name="remove_from_favorite">Remove from Favorite</button>
                    </form>
                </div>
            <?php } ?>
        <?php } else { ?>
            <p>You have no favorite games yet.</p>
        <?php } ?>
    </div>
</body>
</html>
