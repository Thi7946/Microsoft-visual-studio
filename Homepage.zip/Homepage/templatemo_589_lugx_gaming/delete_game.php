<?php
include 'connect.php'; // เชื่อมต่อฐานข้อมูล

// ฟังก์ชันสำหรับรัน SQL
function executeQuery($sql) {
    global $conn;
    $result = mysqli_query($conn, $sql);
    if (!$result) {
        die('ข้อผิดพลาดในการดำเนินการ: ' . mysqli_error($conn));
    }
    return $result;
}

if (isset($_GET['game_id'])) {
    $game_id = $_GET['game_id'];

    // ลบเกมจากฐานข้อมูล
    $delete_sql = "DELETE FROM games WHERE game_id = '$game_id'";
    executeQuery($delete_sql);

    // คุณอาจต้องการลบรูปภาพที่เกี่ยวข้องด้วย ถ้าต้องการ

    // กลับไปหน้าเดิมหลังจากลบ
    header("Location:gameedit.php");
    exit();
} else {
    echo "ไม่พบเกมที่ต้องการลบ";
}
?>
