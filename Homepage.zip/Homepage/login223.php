if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // รับค่าจากฟอร์ม
    if (isset($_POST['register'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username_account']);
        $email = mysqli_real_escape_string($conn, $_POST['email_account']);
        $password = mysqli_real_escape_string($conn, $_POST['password_account']);
        $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
        
        // ตรวจสอบว่ารหัสผ่านตรงกันหรือไม่
        if ($password !== $confirm_password) {
            $message = "Passwords do not match!";
        } else {
            // ตรวจสอบว่าอีเมลนี้มีอยู่แล้วหรือไม่
            $check_email_query = "SELECT * FROM account WHERE email_account='$email' LIMIT 1";
            $result = $conn->query($check_email_query);
            
            if ($result->num_rows > 0) {
                $message = "This email is already registered!";
            } else {
                // อัปโหลดภาพโปรไฟล์
                $image_name = $_FILES['profile_image']['name'];
                $image_tmp = $_FILES['profile_image']['tmp_name'];
                $target_dir = "profile/"; // โฟลเดอร์ที่เก็บรูป
                $target_file = $target_dir . basename($image_name);
                
                // ตรวจสอบว่ามีการอัปโหลดไฟล์
                if (move_uploaded_file($image_tmp, $target_file)) {
                    // บันทึกข้อมูลภาพในตาราง account_image
                    $insert_image_sql = "INSERT INTO account_image (image_name, image_url, created_at) VALUES ('$image_name', '$target_file', NOW())";
                    
                    if ($conn->query($insert_image_sql)) {
                        $image_account_id = $conn->insert_id; // รับ image_account_id ที่สร้างขึ้น
                        
                        // บันทึกข้อมูลลงในฐานข้อมูล
                        $sql = "INSERT INTO account (username_account, email_account, password_account, image_account_id) 
                                VALUES ('$username', '$email', '$password', $image_account_id)";
                        
                        if ($conn->query($sql)) {
                            $message = "Registration successful!";
                        } else {
                            // แสดงข้อผิดพลาด SQL
                            $message = "Error executing SQL: " . $conn->error;
                        }
                    } else {
                        $message = "Failed to save image data.";
                    }
                } else {
                    $message = "Failed to upload image.";
                }
            }
        }
    }
}