<?php  
session_start();
include 'connect.php';

// Function to execute SQL queries
function executeQuery($sql) {
    global $conn;
    return mysqli_query($conn, $sql);
}

// Handle delete request
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    // Delete game first
    $sql = "DELETE FROM games WHERE game_id='$id'";
    executeQuery($sql);

    // Show success message
    echo "<script>alert('ลบข้อมูลเกมเรียบร้อยแล้ว');</script>";
    header("Location: allgames.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบจัดการเกม</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        .game-image {
            width: 100px; /* กำหนดขนาดของรูปภาพเกม */
            height: auto; /* ให้คงสัดส่วนของรูปภาพ */
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mt-4">จัดการเกม</h2>

    <a href="addgame.php" class="btn btn-primary mb-3">เพิ่มเกม</a>

    <!-- Display game list -->
    <h4>รายชื่อเกม</h4>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>รูปภาพ</th>
            <th>รหัสเกม</th>
            <th>ชื่อเกม</th>
            <th>วันวางจำหน่าย</th>
            <th>ผู้พัฒนา</th>
            <th>ประเภท</th>
            <th>คำอธิบาย</th>
            <th>การจัดการ</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // ดึงข้อมูลจากตาราง games ร่วมกับตาราง game_images และ game_categories
        $sql = "SELECT g.game_id, g.game_name, g.release_date, g.developer, c.category_name, 
                       g.description, gi.image
                FROM games g
                LEFT JOIN game_categories c ON g.category_id = c.category_id
                LEFT JOIN game_images gi ON g.image_game_id = gi.image_game_id";
        $result = executeQuery($sql);

        // แสดงข้อมูลในตาราง
        while ($game = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            // แสดงรูปภาพ
            echo "<td><img src='" . htmlspecialchars($game['image']) . "' alt='Game Image' class='game-image'></td>";
            echo "<td>{$game['game_id']}</td>";
            echo "<td>{$game['game_name']}</td>";
            echo "<td>{$game['release_date']}</td>";
            echo "<td>{$game['developer']}</td>";
            echo "<td>{$game['category_name']}</td>";
            echo "<td>{$game['description']}</td>";
            echo "<td>
                    <a href='gameedit.php?edit={$game['game_id']}' class='btn btn-warning'>แก้ไข</a>
                    <a href='?delete={$game['game_id']}' class='btn btn-danger' onclick=\"return confirm('คุณแน่ใจว่าต้องการลบข้อมูลเกมนี้?');\">ลบ</a>
                  </td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
