<?php
session_start();

$hostname_surachet = "localhost";
$database_surachet = "u299560388_651237";
$username_surachet = "u299560388_651237";
$password_surachet = "EL5811Lt";
$surachet = mysqli_connect($hostname_surachet, $username_surachet, $password_surachet, $database_surachet);

if (!$surachet) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to execute SQL queries
function executeQuery($sql) {
    global $surachet;
    return mysqli_query($surachet, $sql);
}

// Handle delete request
if (isset($_GET['delete'])) {
    $sid = $_GET['delete'];

    // Delete hobbies first
    $deleteHobbySQL = "DELETE FROM tbl_studenthobby WHERE SID='$sid'";
    executeQuery($deleteHobbySQL);

    // Delete student
    $sql = "DELETE FROM tbl_student WHERE SID='$sid'";
    executeQuery($sql);

    // Show success message
    echo "<script>alert('ลบข้อมูลนักศึกษาเรียบร้อยแล้ว');</script>";
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบจัดการนักศึกษา</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2 class="mt-4">จัดการนักศึกษา</h2>

    <a href="insert.php" class="btn btn-primary mb-3">เพิ่มนักศึกษา</a>

    <!-- Display student list -->
    <h4>รายชื่อนักศึกษา</h4>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>รหัส</th>
            <th>ชื่อ</th>
            <th>นามสกุล</th>
            <th>งานอดิเรก</th>
            <th>การจัดการ</th>
        </tr>
        </thead>
        <tbody>
        <?php
        // ปรับคำสั่ง SQL เพื่อรวมข้อมูลงานอดิเรก
        $sql = "
        SELECT s.*, 
               GROUP_CONCAT(h.HobbyName SEPARATOR ', ') AS Hobbies
        FROM tbl_student s
        LEFT JOIN tbl_studenthobby sh ON s.SID = sh.SID
        LEFT JOIN tbl_hobby h ON sh.HobbyID = h.HobbyID
        GROUP BY s.SID
        ";
        
        $result = executeQuery($sql);
        while ($student = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>{$student['SID']}</td>";
            echo "<td>{$student['StudentName']}</td>";
            echo "<td>{$student['StudentLastname']}</td>";
            echo "<td>{$student['Hobbies']}</td>"; // แสดงงานอดิเรกที่รวมกัน
            echo "<td>
                    <a href='edit.php?edit={$student['SID']}' class='btn btn-warning'>แก้ไข</a>
                    <a href='?delete={$student['SID']}' class='btn btn-danger' onclick=\"return confirm('คุณแน่ใจว่าต้องการลบข้อมูลนักเรียนนี้?');\">ลบ</a>
                  </td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
