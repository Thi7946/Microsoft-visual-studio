import requests
from bs4 import BeautifulSoup
from googletrans import Translator

# กำหนด URL ของหน้าเว็บที่คุณต้องการแปล
url = 'https://www.qidian.com/chapter/1037921164/803479693/'

# ดึงข้อมูลจากหน้าเว็บ
response = requests.get(url)
html_content = response.text

# ใช้ BeautifulSoup เพื่อแยกเนื้อหา
soup = BeautifulSoup(html_content, 'html.parser')

# สมมติว่าคุณต้องการแปลเนื้อหาในแท็ก <p>
texts = [p.get_text() for p in soup.find_all('p')]

# สร้างอ็อบเจ็กต์ Translator
translator = Translator()

# แปลเนื้อหา (จากจีนเป็นไทย)
translated_texts = [translator.translate(text, src='zh-cn', dest='th').text for text in texts]

# แสดงผลลัพธ์
for original, translated in zip(texts, translated_texts):
    print(f"Original: {original}")
    print(f"Translated: {translated}")
    print()

