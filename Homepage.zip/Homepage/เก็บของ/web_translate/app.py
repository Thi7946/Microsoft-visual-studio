from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup
from googletrans import Translator

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    translated_texts = []
    if request.method == 'POST':
        url = request.form['url']
        try:
            # ดึงข้อมูลจากหน้าเว็บ
            response = requests.get(url)
            html_content = response.text

            # ใช้ BeautifulSoup เพื่อแยกเนื้อหา
            soup = BeautifulSoup(html_content, 'html.parser')

            # สมมติว่าคุณต้องการแปลเนื้อหาในแท็ก <p>
            texts = [p.get_text() for p in soup.find_all('p')]

            # สร้างอ็อบเจ็กต์ Translator
            translator = Translator()

            # แปลเนื้อหา (จากจีนเป็นไทย)
            translated_texts = [translator.translate(text, src='zh-cn', dest='th').text for text in texts]

        except Exception as e:
            translated_texts = [str(e)]

    return render_template('index.html', translated_texts=translated_texts)

if __name__ == '__main__':
    app.run(debug=True)
