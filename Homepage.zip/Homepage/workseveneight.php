<?php
session_start();

$hostname_surachet = "localhost";
$database_surachet = "u299560388_651237";
$username_surachet = "u299560388_651237";
$password_surachet = "EL5811Lt";
$surachet = mysqli_connect($hostname_surachet, $username_surachet, $password_surachet, $database_surachet);

if (!$surachet) {
    die("การเชื่อมต่อล้มเหลว: " . mysqli_connect_error());
}

function executeQuery($sql) {
    global $surachet;
    return mysqli_query($surachet, $sql);
}

// สำหรับจัดการการเพิ่ม/แก้ไขนักศึกษา
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sid = $_POST['SID'];
    $name = $_POST['StudentName'];
    $lastname = $_POST['StudentLastname'];
    $age = $_POST['Age'];
    $year = $_POST['Year'];
    $address = $_POST['Address'];
    $telephone = $_POST['Telephone'];
    $depID = $_POST['DepID'];

    if (empty($sid)) {
        // เพิ่มข้อมูลนักศึกษาใหม่
        $sql = "INSERT INTO tbl_student (StudentName, StudentLastname, Age, Year, Address, Telephone, DepID)
                VALUES ('$name', '$lastname', '$age', '$year', '$address', '$telephone', '$depID')";
    } else {
        // แก้ไขข้อมูลนักศึกษา
        $sql = "UPDATE tbl_student SET 
                StudentName='$name', StudentLastname='$lastname', Age='$age', Year='$year', 
                Address='$address', Telephone='$telephone', DepID='$depID' WHERE SID='$sid'";
    }
    
    // ตรวจสอบการดำเนินการ SQL
    if (executeQuery($sql)) {
        header("Location: " . $_SERVER['PHP_SELF']);
        exit(); // ป้องกันการส่งข้อมูลซ้ำ
    } else {
        echo "ข้อผิดพลาดในการบันทึกข้อมูล: " . mysqli_error($surachet);
    }
}

if (isset($_GET['delete'])) {
    $sid = $_GET['delete'];
    $sql = "DELETE FROM tbl_student WHERE SID='$sid'";
    executeQuery($sql);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit(); // ป้องกันการส่งข้อมูลซ้ำ
}

// ดึงข้อมูลนักศึกษาและข้อมูลแผนกที่เกี่ยวข้องเมื่อแก้ไข
$student = null;
if (isset($_GET['edit'])) {
    $sid = $_GET['edit'];
    if (!is_numeric($sid)) {
        die("รหัสนักศึกษาไม่ถูกต้อง");
    }
    
    $sql = "SELECT s.*, d.Department FROM tbl_student s 
            LEFT JOIN tbl_department d ON s.DepID = d.DepID 
            WHERE s.SID='$sid'";
    $result = executeQuery($sql);
    
    if ($result) {
        $student = mysqli_fetch_assoc($result);
        if (!$student) {
            echo "ไม่พบข้อมูลนักศึกษา";
        }
    } else {
        echo "ข้อผิดพลาดในการดึงข้อมูล: " . mysqli_error($surachet);
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ระบบจัดการนักศึกษา</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2 class="mt-4">จัดการนักศึกษา</h2>

    <!-- ฟอร์มสำหรับเพิ่ม/แก้ไขนักศึกษา -->
    <form action="" method="POST">
        <div class="form-group">
            <label for="StudentName">ชื่อ</label>
            <input type="text" class="form-control" id="StudentName" name="StudentName" value="<?php echo isset($student['StudentName']) ? htmlspecialchars($student['StudentName']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="StudentLastname">นามสกุล</label>
            <input type="text" class="form-control" id="StudentLastname" name="StudentLastname" value="<?php echo isset($student['StudentLastname']) ? htmlspecialchars($student['StudentLastname']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="Age">อายุ</label>
            <input type="number" class="form-control" id="Age" name="Age" value="<?php echo isset($student['Age']) ? htmlspecialchars($student['Age']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="Year">ปีการศึกษา</label>
            <input type="number" class="form-control" id="Year" name="Year" value="<?php echo isset($student['Year']) ? htmlspecialchars($student['Year']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="Address">ที่อยู่</label>
            <textarea class="form-control" id="Address" name="Address" required><?php echo isset($student['Address']) ? htmlspecialchars($student['Address']) : ''; ?></textarea>
        </div>
        <div class="form-group">
            <label for="Telephone">เบอร์โทรศัพท์</label>
            <input type="text" class="form-control" id="Telephone" name="Telephone" value="<?php echo isset($student['Telephone']) ? htmlspecialchars($student['Telephone']) : ''; ?>" required>
        </div>
        <div class="form-group">
            <label for="DepID">แผนก</label>
            <select class="form-control" id="DepID" name="DepID" required>
                <option value="">เลือกแผนก</option>
                <?php
                // ดึงข้อมูลแผนกจากฐานข้อมูล
                $sql_department = "SELECT * FROM tbl_department";
                $result_department = executeQuery($sql_department);
                while ($department = mysqli_fetch_assoc($result_department)) {
                    $selected = (isset($student['DepID']) && $department['DebID'] == $student['DepID']) ? 'selected' : '';
                    echo "<option value='{$department['DebID']}' $selected>{$department['Department']}</option>";
                }
                ?>
            </select>
        </div>
        <input type="hidden" name="SID" value="<?php echo isset($student['SID']) ? htmlspecialchars($student['SID']) : ''; ?>">
        <button type="submit" class="btn btn-primary" name="SaveStudent">บันทึก</button>
    </form>

    <hr>

    <!-- แสดงรายชื่อนักศึกษา -->
    <h4>รายชื่อนักศึกษา</h4>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>รหัส</th>
            <th>ชื่อ</th>
            <th>นามสกุล</th>
            <th>การจัดการ</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM tbl_student";
        $result = executeQuery($sql);
        while ($student = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>{$student['SID']}</td>";
            echo "<td>{$student['StudentName']}</td>";
            echo "<td>{$student['StudentLastname']}</td>";
            echo "<td>
                    <a href='?edit={$student['SID']}' class='btn btn-warning'>แก้ไข</a>
                    <a href='?delete={$student['SID']}' class='btn btn-danger'>ลบ</a>
                  </td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
