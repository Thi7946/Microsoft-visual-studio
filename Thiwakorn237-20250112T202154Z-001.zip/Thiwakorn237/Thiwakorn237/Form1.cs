﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Thiwakorn237
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void NUD1_ValueChanged(object sender, EventArgs e)
        {
            int N, P, SUM;
            N = Convert.ToInt32(NUD1.Value.ToString());
            P = Convert.ToInt32(LB1.Text);
            SUM = N * P;
            LBP1.Text = SUM.ToString();
        }

        private void NUD2_ValueChanged(object sender, EventArgs e)
        {
            int N, P, SUM;
            N = Convert.ToInt32(NUD2.Value.ToString());
            P = Convert.ToInt32(LB2.Text);
            SUM = N * P;
            LBP2.Text = SUM.ToString();
        }

        private void NUD3_ValueChanged(object sender, EventArgs e)
        {
            int N, P, SUM;
            N = Convert.ToInt32(NUD3.Value.ToString());
            P = Convert.ToInt32(LB3.Text);
            SUM = N * P;
            LBP3.Text = SUM.ToString();
        }

        private void NUD4_ValueChanged(object sender, EventArgs e)
        {
            int N, P, SUM;
            N = Convert.ToInt32(NUD4.Value.ToString());
            P = Convert.ToInt32(LB4.Text);
            SUM = N * P;
            LBP4.Text = SUM.ToString();
        }
        private void CALSUMP()
        {
            int P1,P2,P3,P4,SUMP;
            P1 = Convert.ToInt32(LBP1.Text);
            P2 = Convert.ToInt32(LBP2.Text);
            P3 = Convert.ToInt32(LBP3.Text);
            P4 = Convert.ToInt32(LBP4.Text);
            SUMP = P1 + P2 + P3 + P4;
            LBPSUM.Text = SUMP.ToString();
        }


        private void LBP1_TextChanged(object sender, EventArgs e)
        {
            CALSUMP();
        }

        private void LBDC_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id;
            double PR, DC=0, SUMP;
            PR = Convert.ToDouble(LBPSUM.Text);
            id = CBMB.SelectedIndex;
            switch (id)
            {
                case 0:
                    DC = 0;
                    break;
                case 1:
                    DC = 0.05 * PR;
                    break;
                case 2:
                    DC = 0.1 * PR;
                    break;
                case 3:
                    DC = 0.2 * PR;
                    break;
                default:
                    break;
            }
            LBDC.Text = DC.ToString();
            SUMP = PR - DC;
            LBSUMALL.Text = SUMP.ToString();

        }

        private void CBMENU1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int price;
            double PR, PP = 0, SUMP;
            PR = Convert.ToDouble(LB1.Text);
            price = CBMENU1.SelectedIndex;
            switch (price)
            {
                case 0:
                    PP = 52;
                    break;
                case 1:
                    PP = 45;
                    break;
                case 2:
                    PP = 40;
                    break;
                case 3:
                    PP = 50;
                    break;
                case 4:
                    PP = 55;
                    break;
                case 5:
                    PP = 56;
                    break;
                default:
                    break;
            }
            CBMENU1.Text = PP.ToString();
            SUMP = PP;
            LB1.Text = SUMP.ToString();
        }

        private void CBMENU2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int price;
            double PR, PP = 0, SUMP;
            PR = Convert.ToDouble(LB1.Text);
            price = CBMENU2.SelectedIndex;
            switch (price)
            {
                case 0:
                    PP = 52;
                    break;
                case 1:
                    PP = 45;
                    break;
                case 2:
                    PP = 40;
                    break;
                case 3:
                    PP = 50;
                    break;
                case 4:
                    PP = 55;
                    break;
                case 5:
                    PP = 56;
                    break;
                default:
                    break;
            }
            CBMENU2.Text = PP.ToString();
            SUMP = PP;
            LB2.Text = SUMP.ToString();
        }

        private void CBMENU3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int price;
            double PR, PP = 0, SUMP;
            PR = Convert.ToDouble(LB1.Text);
            price = CBMENU3.SelectedIndex;
            switch (price)
            {
                case 0:
                    PP = 52;
                    break;
                case 1:
                    PP = 45;
                    break;
                case 2:
                    PP = 40;
                    break;
                case 3:
                    PP = 50;
                    break;
                case 4:
                    PP = 55;
                    break;
                case 5:
                    PP = 56;
                    break;
                default:
                    break;
            }
            CBMENU3.Text = PP.ToString();
            SUMP = PP;
            LB3.Text = SUMP.ToString();
        }

        private void CBMENU4_SelectedIndexChanged(object sender, EventArgs e)
        {
            int price;
            double PR, PP = 0, SUMP;
            PR = Convert.ToDouble(LB1.Text);
            price = CBMENU4.SelectedIndex;
            switch (price)
            {
                case 0:
                    PP = 52;
                    break;
                case 1:
                    PP = 45;
                    break;
                case 2:
                    PP = 40;
                    break;
                case 3:
                    PP = 50;
                    break;
                case 4:
                    PP = 55;
                    break;
                case 5:
                    PP = 56;
                    break;
                default:
                    break;
            }
            CBMENU4.Text = PP.ToString();
            SUMP = PP;
            LB4.Text = SUMP.ToString();
        }        
    }
}
