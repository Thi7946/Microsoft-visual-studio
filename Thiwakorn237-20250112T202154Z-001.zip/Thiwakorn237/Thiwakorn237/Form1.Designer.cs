﻿namespace Thiwakorn237
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.LB4 = new System.Windows.Forms.Label();
            this.LB3 = new System.Windows.Forms.Label();
            this.LB2 = new System.Windows.Forms.Label();
            this.LB1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.NUD1 = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.NUD2 = new System.Windows.Forms.NumericUpDown();
            this.NUD3 = new System.Windows.Forms.NumericUpDown();
            this.NUD4 = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.LBP2 = new System.Windows.Forms.Label();
            this.LBP1 = new System.Windows.Forms.Label();
            this.LBP4 = new System.Windows.Forms.Label();
            this.LBP3 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.LBPSUM = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.CBMB = new System.Windows.Forms.ComboBox();
            this.LBDC = new System.Windows.Forms.Label();
            this.LBSUMALL = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.CBMENU1 = new System.Windows.Forms.ComboBox();
            this.CBMENU2 = new System.Windows.Forms.ComboBox();
            this.CBMENU3 = new System.Windows.Forms.ComboBox();
            this.CBMENU4 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.NUD1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(110, 119);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "รายการอาหาร";
            // 
            // LB4
            // 
            this.LB4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB4.Location = new System.Drawing.Point(280, 325);
            this.LB4.Name = "LB4";
            this.LB4.Size = new System.Drawing.Size(126, 23);
            this.LB4.TabIndex = 10;
            this.LB4.Text = "0";
            // 
            // LB3
            // 
            this.LB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB3.Location = new System.Drawing.Point(280, 278);
            this.LB3.Name = "LB3";
            this.LB3.Size = new System.Drawing.Size(116, 23);
            this.LB3.TabIndex = 9;
            this.LB3.Text = "0";
            // 
            // LB2
            // 
            this.LB2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB2.Location = new System.Drawing.Point(280, 226);
            this.LB2.Name = "LB2";
            this.LB2.Size = new System.Drawing.Size(126, 23);
            this.LB2.TabIndex = 8;
            this.LB2.Text = "0";
            // 
            // LB1
            // 
            this.LB1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB1.Location = new System.Drawing.Point(280, 171);
            this.LB1.Name = "LB1";
            this.LB1.Size = new System.Drawing.Size(116, 23);
            this.LB1.TabIndex = 7;
            this.LB1.Text = "0";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(270, 119);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(136, 23);
            this.label10.TabIndex = 6;
            this.label10.Text = "ราคา";
            // 
            // NUD1
            // 
            this.NUD1.Location = new System.Drawing.Point(396, 178);
            this.NUD1.Name = "NUD1";
            this.NUD1.Size = new System.Drawing.Size(120, 20);
            this.NUD1.TabIndex = 11;
            this.NUD1.ValueChanged += new System.EventHandler(this.NUD1_ValueChanged);
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(396, 119);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(136, 23);
            this.label11.TabIndex = 12;
            this.label11.Text = "จำนวน";
            // 
            // NUD2
            // 
            this.NUD2.Location = new System.Drawing.Point(396, 229);
            this.NUD2.Name = "NUD2";
            this.NUD2.Size = new System.Drawing.Size(120, 20);
            this.NUD2.TabIndex = 13;
            this.NUD2.ValueChanged += new System.EventHandler(this.NUD2_ValueChanged);
            // 
            // NUD3
            // 
            this.NUD3.Location = new System.Drawing.Point(396, 278);
            this.NUD3.Name = "NUD3";
            this.NUD3.Size = new System.Drawing.Size(120, 20);
            this.NUD3.TabIndex = 14;
            this.NUD3.ValueChanged += new System.EventHandler(this.NUD3_ValueChanged);
            // 
            // NUD4
            // 
            this.NUD4.Location = new System.Drawing.Point(396, 325);
            this.NUD4.Name = "NUD4";
            this.NUD4.Size = new System.Drawing.Size(120, 20);
            this.NUD4.TabIndex = 15;
            this.NUD4.ValueChanged += new System.EventHandler(this.NUD4_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(575, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 26);
            this.label12.TabIndex = 16;
            this.label12.Text = "ราคาสินค้า";
            // 
            // LBP2
            // 
            this.LBP2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBP2.Location = new System.Drawing.Point(574, 226);
            this.LBP2.Name = "LBP2";
            this.LBP2.Size = new System.Drawing.Size(117, 23);
            this.LBP2.TabIndex = 18;
            this.LBP2.Text = "0";
            this.LBP2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.LBP2.TextChanged += new System.EventHandler(this.LBP1_TextChanged);
            // 
            // LBP1
            // 
            this.LBP1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBP1.Location = new System.Drawing.Point(575, 178);
            this.LBP1.Name = "LBP1";
            this.LBP1.Size = new System.Drawing.Size(116, 23);
            this.LBP1.TabIndex = 17;
            this.LBP1.Text = "0";
            this.LBP1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.LBP1.TextChanged += new System.EventHandler(this.LBP1_TextChanged);
            // 
            // LBP4
            // 
            this.LBP4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBP4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBP4.Location = new System.Drawing.Point(574, 325);
            this.LBP4.Name = "LBP4";
            this.LBP4.Size = new System.Drawing.Size(117, 23);
            this.LBP4.TabIndex = 20;
            this.LBP4.Text = "0";
            this.LBP4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.LBP4.TextChanged += new System.EventHandler(this.LBP1_TextChanged);
            // 
            // LBP3
            // 
            this.LBP3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBP3.Location = new System.Drawing.Point(575, 277);
            this.LBP3.Name = "LBP3";
            this.LBP3.Size = new System.Drawing.Size(116, 23);
            this.LBP3.TabIndex = 19;
            this.LBP3.Text = "0";
            this.LBP3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.LBP3.TextChanged += new System.EventHandler(this.LBP1_TextChanged);
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(399, 475);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(117, 23);
            this.label17.TabIndex = 22;
            this.label17.Text = "ราคาข้าว";
            // 
            // LBPSUM
            // 
            this.LBPSUM.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBPSUM.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBPSUM.Location = new System.Drawing.Point(575, 475);
            this.LBPSUM.Name = "LBPSUM";
            this.LBPSUM.Size = new System.Drawing.Size(116, 23);
            this.LBPSUM.TabIndex = 21;
            this.LBPSUM.Text = "0";
            this.LBPSUM.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.LBPSUM.TextChanged += new System.EventHandler(this.Form1_Load);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(372, 523);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(160, 23);
            this.label6.TabIndex = 23;
            this.label6.Text = "ส่วนลดค่าสมาชิก";
            // 
            // CBMB
            // 
            this.CBMB.BackColor = System.Drawing.SystemColors.Window;
            this.CBMB.FormattingEnabled = true;
            this.CBMB.Items.AddRange(new object[] {
            "ไม่เป็นสมาชิก",
            "ลด 5%",
            "ลด10%",
            "โปรเดือนเกิด"});
            this.CBMB.Location = new System.Drawing.Point(245, 529);
            this.CBMB.Name = "CBMB";
            this.CBMB.Size = new System.Drawing.Size(121, 21);
            this.CBMB.TabIndex = 24;
            this.CBMB.SelectedIndexChanged += new System.EventHandler(this.LBDC_SelectedIndexChanged);
            // 
            // LBDC
            // 
            this.LBDC.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBDC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBDC.Location = new System.Drawing.Point(574, 523);
            this.LBDC.Name = "LBDC";
            this.LBDC.Size = new System.Drawing.Size(116, 23);
            this.LBDC.TabIndex = 25;
            this.LBDC.Text = "0";
            this.LBDC.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // LBSUMALL
            // 
            this.LBSUMALL.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBSUMALL.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBSUMALL.Location = new System.Drawing.Point(574, 578);
            this.LBSUMALL.Name = "LBSUMALL";
            this.LBSUMALL.Size = new System.Drawing.Size(116, 23);
            this.LBSUMALL.TabIndex = 26;
            this.LBSUMALL.Text = "0";
            this.LBSUMALL.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(399, 578);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 23);
            this.label8.TabIndex = 27;
            this.label8.Text = "ราคารวม";
            // 
            // CBMENU1
            // 
            this.CBMENU1.FormattingEnabled = true;
            this.CBMENU1.Items.AddRange(new object[] {
            "ข้าวผัดไข่",
            "ข้าวกะเพลา",
            "ข้าวไข่เจียวหมูสับ",
            "ข้าวหมูทอด",
            "ข้าวต้ม",
            "ข้าวหมูแดดเดียว"});
            this.CBMENU1.Location = new System.Drawing.Point(115, 171);
            this.CBMENU1.Name = "CBMENU1";
            this.CBMENU1.Size = new System.Drawing.Size(121, 21);
            this.CBMENU1.TabIndex = 28;
            this.CBMENU1.SelectedIndexChanged += new System.EventHandler(this.CBMENU1_SelectedIndexChanged);
            // 
            // CBMENU2
            // 
            this.CBMENU2.FormattingEnabled = true;
            this.CBMENU2.Items.AddRange(new object[] {
            "ข้าวผัดไข่",
            "ข้าวกะเพลา",
            "ข้าวไข่เจียวหมูสับ",
            "ข้าวหมูทอด",
            "ข้าวต้ม",
            "ข้าวหมูแดดเดียว"});
            this.CBMENU2.Location = new System.Drawing.Point(115, 226);
            this.CBMENU2.Name = "CBMENU2";
            this.CBMENU2.Size = new System.Drawing.Size(121, 21);
            this.CBMENU2.TabIndex = 29;
            this.CBMENU2.SelectedIndexChanged += new System.EventHandler(this.CBMENU2_SelectedIndexChanged);
            // 
            // CBMENU3
            // 
            this.CBMENU3.FormattingEnabled = true;
            this.CBMENU3.Items.AddRange(new object[] {
            "ข้าวผัดไข่",
            "ข้าวกะเพลา",
            "ข้าวไข่เจียวหมูสับ",
            "ข้าวหมูทอด",
            "ข้าวต้ม",
            "ข้าวหมูแดดเดียว"});
            this.CBMENU3.Location = new System.Drawing.Point(115, 280);
            this.CBMENU3.Name = "CBMENU3";
            this.CBMENU3.Size = new System.Drawing.Size(121, 21);
            this.CBMENU3.TabIndex = 30;
            this.CBMENU3.SelectedIndexChanged += new System.EventHandler(this.CBMENU3_SelectedIndexChanged);
            // 
            // CBMENU4
            // 
            this.CBMENU4.FormattingEnabled = true;
            this.CBMENU4.Items.AddRange(new object[] {
            "ข้าวผัดไข่",
            "ข้าวกะเพลา",
            "ข้าวไข่เจียวหมูสับ",
            "ข้าวหมูทอด",
            "ข้าวต้ม",
            "ข้าวหมูแดดเดียว"});
            this.CBMENU4.Location = new System.Drawing.Point(115, 331);
            this.CBMENU4.Name = "CBMENU4";
            this.CBMENU4.Size = new System.Drawing.Size(121, 21);
            this.CBMENU4.TabIndex = 31;
            this.CBMENU4.SelectedIndexChanged += new System.EventHandler(this.CBMENU4_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1014, 824);
            this.Controls.Add(this.CBMENU4);
            this.Controls.Add(this.CBMENU3);
            this.Controls.Add(this.CBMENU2);
            this.Controls.Add(this.CBMENU1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.LBSUMALL);
            this.Controls.Add(this.LBDC);
            this.Controls.Add(this.CBMB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.LBPSUM);
            this.Controls.Add(this.LBP4);
            this.Controls.Add(this.LBP3);
            this.Controls.Add(this.LBP2);
            this.Controls.Add(this.LBP1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.NUD4);
            this.Controls.Add(this.NUD3);
            this.Controls.Add(this.NUD2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.NUD1);
            this.Controls.Add(this.LB4);
            this.Controls.Add(this.LB3);
            this.Controls.Add(this.LB2);
            this.Controls.Add(this.LB1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TextChanged += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.NUD1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LB4;
        private System.Windows.Forms.Label LB3;
        private System.Windows.Forms.Label LB2;
        private System.Windows.Forms.Label LB1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown NUD1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown NUD2;
        private System.Windows.Forms.NumericUpDown NUD3;
        private System.Windows.Forms.NumericUpDown NUD4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label LBP2;
        private System.Windows.Forms.Label LBP1;
        private System.Windows.Forms.Label LBP4;
        private System.Windows.Forms.Label LBP3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label LBPSUM;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox CBMB;
        private System.Windows.Forms.Label LBDC;
        private System.Windows.Forms.Label LBSUMALL;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox CBMENU1;
        private System.Windows.Forms.ComboBox CBMENU2;
        private System.Windows.Forms.ComboBox CBMENU3;
        private System.Windows.Forms.ComboBox CBMENU4;
    }
}

