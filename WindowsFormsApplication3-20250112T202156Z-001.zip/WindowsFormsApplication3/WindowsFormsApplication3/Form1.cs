﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace work2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ListViewItem Lvi = default(ListViewItem);
        double AT = 0, PR, TB1, TB2, TB3, TB4;
        string ST, TTP1, TTp2, TTp3, TTp4;
        //int A = 0;
        double B = 0;

        private void CBMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id;
            id = Convert.ToInt32(CBMenu.SelectedIndex.ToString());
            switch (id)
            {
                case 0:
                    PR = 55;
                    break;
                case 1:
                    PR = 45;
                    break;
                case 2:
                    PR = 45;
                    break;
                case 3:
                    PR = 55;
                    break;
                case 4:
                    PR = 55;
                    break;
                case 5:
                    PR = 55;
                    break;
                case 6:
                    PR = 55;
                    break;
                case 7:
                    PR = 45;
                    break;
                default:
                    PR = 0;
                    break;
            }
            CALSUM();
        }

        private void CBT_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id;
            double OP;
            id = Convert.ToInt32(CBT.SelectedIndex.ToString());
            OP = PR;
            switch (id)
            {
                case 0:
                    AT = 0;
                    break;
                case 1:
                    AT = 10;
                    break;
                default:
                    break;
            }
            CALSUM();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LBOrder.View = View.Details;
        }

        private void CBtp1_CheckedChanged(object sender, EventArgs e)
        {
            if (CBtp1.Checked == true)
            {
                TB1 = 15;
                TTP1 = CBtp1.Text;
            }
            else
            {
                TB1 = 0;
                TTP1 = " ";
            }
            CALSUM();
        }

        private void CBtp2_CheckedChanged(object sender, EventArgs e)
        {
            if (CBtp2.Checked == true)
            {
                TB2 = 10;
                TTp2 = CBtp2.Text;
            }
            else
            {
                TB2 = 0;
                TTp2 = " ";
            }
            CALSUM();
        }

        private void CBtp3_CheckedChanged(object sender, EventArgs e)
        {
            if (CBtp3.Checked == true)
            {
                TB3 = 10;
                TTp3 = CBtp3.Text;
            }
            else
            {
                TB3 = 0;
                TTp3 = " ";
            }
            CALSUM();
        }
        private void CBtp4_CheckedChanged(object sender, EventArgs e)
        {
            if (CBtp4.Checked == true)
            {
                TB4 = 10;
                TTp4 = CBtp4.Text;
            }
            else
            {
                TB4 = 0;
                TTp4 = " ";
            }
            CALSUM();
        }
        private void CALSUM()
        {
            double SUMP,NUM;
            NUM = Convert.ToInt32(NUD1.Value.ToString());
            SUMP = (PR + AT + TB1 + TB2 + TB3 + TB4)*NUM ;
            LBpr.Text = SUMP.ToString();
            if (RBst1.Checked == true)
            {
                ST = RBst1.Text;
            }
            else
            {
                if (RBst2.Checked == true)
                {
                    ST = RBst2.Text;
                }
                else
                {
                    if (RBst3.Checked == true)
                    {
                        ST = RBst3.Text;
                    }
                    else
                    {
                        if (RBst4.Checked == true)
                        {
                            ST = RBst4.Text;
                        }
                    }
                }
            }
        }
        private void CL()
        {
            CBMenu.Text = "";
            CBT.Text = "";
            RBst4.Checked = true;
            CBtp1.Checked = false;
            CBtp2.Checked = false;
            CBtp3.Checked = false;
            CBtp4.Checked = false;
            NUD1.Value = 1;
            LBpr.Text = "0";
        }

        private void BTadd_Click(object sender, EventArgs e)
        {
            if (CBMenu.Text != "")
            {
                if (CBT.Text != "")
                {

                    Lvi = LBOrder.Items.Add(CBMenu.Text);
                    Lvi.SubItems.Add(CBT.Text);
                    Lvi.SubItems.Add(ST);
                    Lvi.SubItems.Add(TTP1);
                    Lvi.SubItems.Add(TTp2);
                    Lvi.SubItems.Add(TTp3);
                    Lvi.SubItems.Add(TTp4);
                    Lvi.SubItems.Add(NUD1.Text);
                    Lvi.SubItems.Add(LBpr.Text);
                    CL();
                    BTDL.Enabled = true;
                    BTCL.Enabled = true;
                    BTED.Enabled = true;
                }
                else
                {
                    MessageBox.Show("กรุณาเลือกเครื่องดื่ม");
                }
            }
            else
            {
                
            MessageBox.Show("เลือกร้อนเย็น");
                
            }
        }

        private void BTDL_Click(object sender, EventArgs e)
        {
            if (LBOrder.SelectedItems.Count > 0)
            {
                DialogResult dai = MessageBox.Show("ต้องการลบข้อมูลลบ ใช่ / ไม่", "ลบข้อมูล", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dai == DialogResult.Yes)
                {
                    Lvi = LBOrder.SelectedItems[0];
                    Lvi.Remove();
                    MessageBox.Show("ลบข้อมูลแล้ว", "รายงาน");

                }
            }
            else
            {
                MessageBox.Show("กรุณาเลือกรายการลบ");
            }
            if (LBOrder.Items.Count == 0) 
            {
                BTDL .Enabled =false ;
                BTCL .Enabled = false ;
            }
        }

        private void BTCL_Click(object sender, EventArgs e)
        {
            DialogResult dai = MessageBox.Show("ต้องการลบข้อมูลลบข้อมูลทั้งหมด ใช่ / ไม่", "ลบข้อมูลทั้งหมด", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dai == DialogResult.Yes)
            {
                LBOrder.Clear();
                MessageBox.Show("ลบข้อมูลทั้งหมดแล้ว", "รายงาน");
            }
        }

        private void RBst3_CheckedChanged(object sender, EventArgs e)
        {

        }

       

        
 

        private void RBst1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            LBOrder.View = View.Details;
            BTED.Enabled = false;
            BTDL.Enabled = false;
            BTCL.Enabled = false;
        }

        private void LBOrder_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void LBOrder_SelectedIndexChanged_2(object sender, EventArgs e)
        {

        }

        private void LBOrder_DoubleClick(object sender, EventArgs e)
        {
            String LST, NTP1, NTP2, NTP3, NTP4;
            Lvi = LBOrder.SelectedItems[0];
            CBMenu.Text = Lvi.Text;
            CBT.Text = Lvi.SubItems[1].Text;
            LST = Lvi.SubItems[2].Text;
            NTP1 = Lvi.SubItems[3].Text;
            NTP2 = Lvi.SubItems[4].Text;
            NTP3 = Lvi.SubItems[5].Text;
            NTP4 = Lvi.SubItems[6].Text;
            LBpr.Text = Lvi.SubItems[7].Text;
            BTadd.Enabled = false;
            BTDL.Enabled = false;
            BTCL.Enabled = false;
            BTED.Enabled = true;
            if (LST == "ไม่หวาน")
            {
                RBst1.Checked = true;
            }
            else
            {
                if (LST == "หวานน้อย")
                {
                    RBst2.Checked = true;
                }
                else
                {
                    if (LST == "หวานปกติ")
                    {
                        RBst3.Checked = true;
                    }
                    else
                    {
                        if (LST == "หวานมาก")
                        {
                            RBst4.Checked = true;
                        }
                    }
                }
            }
            if (NTP1 != "")
            {
                CBtp1.Checked = true;
            }
            else
            {
                CBtp1.Checked = false;
            }
            if (NTP2 != "")
            {
                CBtp2.Checked = true;
            }
            else
            {
                CBtp2.Checked = false;
            }
            if (NTP3 != "")
            {
                CBtp3.Checked = true;
            }
            else
            {
                CBtp3.Checked = false;
            }
            if (NTP4 != "")
            {
                CBtp4.Checked = true;
            }
            else
            {
                CBtp4.Checked = false;
            }
        }

        private void BTED_Click(object sender, EventArgs e)
        {
            DialogResult dai = MessageBox.Show("ต้องการแก้ไขข้อมูล ใช่ / ไม่", "แก้ไขข้อมูล", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dai == DialogResult.Yes)
            {
                Lvi.Text = CBMenu.Text;
                Lvi.SubItems[1].Text = CBT.Text;
                Lvi.SubItems[2].Text = ST;
                Lvi.SubItems[3].Text = TTP1;
                Lvi.SubItems[4].Text = TTp2;
                Lvi.SubItems[5].Text = TTp3;
                Lvi.SubItems[6].Text = TTp4;
                Lvi.SubItems[7].Text = LBpr.Text;
                CL();
                MessageBox.Show("แก้ไขข้อมูลสำเร็จ", "ยืนยัน");
                BTED.Enabled = false;
                BTDL.Enabled = true;
                BTCL.Enabled = true;
                BTadd.Enabled = true;
            }
        }

        private void NUD1_ValueChanged_1(object sender, EventArgs e)
        {
            CALSUM(); 

        }

        private void RBst4_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}


