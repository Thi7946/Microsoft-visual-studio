﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        public int NUMF6;
      

        private void TBPR_TextChanged(object sender, EventArgs e)
        {
            double Pr, SUM;
            Pr = Convert.ToDouble(TBPR.Text);
            SUM = Pr * NUMF6;
            LBPSUM.Text = SUM.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5.PRF6 = LBPSUM.Text;
            this.Close();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            LBCT.Text = NUMF6.ToString();
        }

    }
}
