﻿namespace WindowsFormsApplication3
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TBCT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LBPRFD = new System.Windows.Forms.Label();
            this.BTFD = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TBCT
            // 
            this.TBCT.Location = new System.Drawing.Point(90, 53);
            this.TBCT.Multiline = true;
            this.TBCT.Name = "TBCT";
            this.TBCT.Size = new System.Drawing.Size(122, 41);
            this.TBCT.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(102, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "จำนวนคน";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(106, 230);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 32);
            this.label2.TabIndex = 6;
            this.label2.Text = "ค่าอาหาร";
            // 
            // LBPRFD
            // 
            this.LBPRFD.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBPRFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBPRFD.Location = new System.Drawing.Point(85, 281);
            this.LBPRFD.Name = "LBPRFD";
            this.LBPRFD.Size = new System.Drawing.Size(131, 32);
            this.LBPRFD.TabIndex = 7;
            this.LBPRFD.Text = "0";
            // 
            // BTFD
            // 
            this.BTFD.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTFD.Location = new System.Drawing.Point(76, 127);
            this.BTFD.Name = "BTFD";
            this.BTFD.Size = new System.Drawing.Size(159, 69);
            this.BTFD.TabIndex = 8;
            this.BTFD.Text = "สั่งอาหาร";
            this.BTFD.UseVisualStyleBackColor = true;
            this.BTFD.Click += new System.EventHandler(this.BTFD_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(76, 364);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(158, 61);
            this.button2.TabIndex = 9;
            this.button2.Text = "สั่งเครื่องดื่ม";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 499);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.BTFD);
            this.Controls.Add(this.LBPRFD);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TBCT);
            this.Name = "Form5";
            this.Text = "Form5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TBCT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LBPRFD;
        private System.Windows.Forms.Button BTFD;
        private System.Windows.Forms.Button button2;
    }
}