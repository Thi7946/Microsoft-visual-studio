﻿namespace work2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.CBMenu = new System.Windows.Forms.ComboBox();
            this.RBst1 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.RBst2 = new System.Windows.Forms.RadioButton();
            this.RBst3 = new System.Windows.Forms.RadioButton();
            this.RBst4 = new System.Windows.Forms.RadioButton();
            this.CBtp1 = new System.Windows.Forms.CheckBox();
            this.CBtp2 = new System.Windows.Forms.CheckBox();
            this.CBtp3 = new System.Windows.Forms.CheckBox();
            this.CBtp4 = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BTadd = new System.Windows.Forms.Button();
            this.CBT = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BTDL = new System.Windows.Forms.Button();
            this.BTCL = new System.Windows.Forms.Button();
            this.LBpr = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.NUD1 = new System.Windows.Forms.NumericUpDown();
            this.LBOrder = new System.Windows.Forms.ListView();
            this.CH1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CHTP1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CHTP2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CHTP3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CHTP4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.BTED = new System.Windows.Forms.Button();
            this.CH6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CH7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this.NUD1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(149, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ชนิดเครื่องดื่ม";
            // 
            // CBMenu
            // 
            this.CBMenu.FormattingEnabled = true;
            this.CBMenu.Items.AddRange(new object[] {
            "กาแฟ",
            "เป็ปซี่",
            "น้ำส้ม",
            "น้ำมะพร้าว",
            "น้ำชามะนาว",
            "ชาเย็น",
            "ชานมเย็น",
            "ชาดำ"});
            this.CBMenu.Location = new System.Drawing.Point(152, 100);
            this.CBMenu.Name = "CBMenu";
            this.CBMenu.Size = new System.Drawing.Size(121, 21);
            this.CBMenu.TabIndex = 1;
            this.CBMenu.SelectedIndexChanged += new System.EventHandler(this.CBMenu_SelectedIndexChanged);
            // 
            // RBst1
            // 
            this.RBst1.AutoSize = true;
            this.RBst1.Location = new System.Drawing.Point(267, 289);
            this.RBst1.Name = "RBst1";
            this.RBst1.Size = new System.Drawing.Size(70, 17);
            this.RBst1.TabIndex = 2;
            this.RBst1.TabStop = true;
            this.RBst1.Text = "หวานมาก";
            this.RBst1.UseVisualStyleBackColor = true;
            this.RBst1.CheckedChanged += new System.EventHandler(this.RBst1_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(149, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "ความหวาน";
            // 
            // RBst2
            // 
            this.RBst2.AutoSize = true;
            this.RBst2.Location = new System.Drawing.Point(267, 244);
            this.RBst2.Name = "RBst2";
            this.RBst2.Size = new System.Drawing.Size(72, 17);
            this.RBst2.TabIndex = 4;
            this.RBst2.TabStop = true;
            this.RBst2.Text = "หวานน้อย";
            this.RBst2.UseVisualStyleBackColor = true;
            // 
            // RBst3
            // 
            this.RBst3.AutoSize = true;
            this.RBst3.Location = new System.Drawing.Point(152, 289);
            this.RBst3.Name = "RBst3";
            this.RBst3.Size = new System.Drawing.Size(72, 17);
            this.RBst3.TabIndex = 5;
            this.RBst3.TabStop = true;
            this.RBst3.Text = "หวานปกติ";
            this.RBst3.UseVisualStyleBackColor = true;
            // 
            // RBst4
            // 
            this.RBst4.AutoSize = true;
            this.RBst4.Location = new System.Drawing.Point(152, 244);
            this.RBst4.Name = "RBst4";
            this.RBst4.Size = new System.Drawing.Size(64, 17);
            this.RBst4.TabIndex = 6;
            this.RBst4.TabStop = true;
            this.RBst4.Text = "ไม่หวาน";
            this.RBst4.UseVisualStyleBackColor = true;
            this.RBst4.CheckedChanged += new System.EventHandler(this.RBst4_CheckedChanged);
            // 
            // CBtp1
            // 
            this.CBtp1.AutoSize = true;
            this.CBtp1.Location = new System.Drawing.Point(152, 349);
            this.CBtp1.Name = "CBtp1";
            this.CBtp1.Size = new System.Drawing.Size(66, 17);
            this.CBtp1.TabIndex = 7;
            this.CBtp1.Text = "เพิ่มช็อค";
            this.CBtp1.UseVisualStyleBackColor = true;
            this.CBtp1.CheckedChanged += new System.EventHandler(this.CBtp1_CheckedChanged);
            // 
            // CBtp2
            // 
            this.CBtp2.AutoSize = true;
            this.CBtp2.Location = new System.Drawing.Point(267, 349);
            this.CBtp2.Name = "CBtp2";
            this.CBtp2.Size = new System.Drawing.Size(51, 17);
            this.CBtp2.TabIndex = 8;
            this.CBtp2.Text = "น้ำผึ้ง";
            this.CBtp2.UseVisualStyleBackColor = true;
            this.CBtp2.CheckedChanged += new System.EventHandler(this.CBtp2_CheckedChanged);
            // 
            // CBtp3
            // 
            this.CBtp3.AutoSize = true;
            this.CBtp3.Location = new System.Drawing.Point(152, 387);
            this.CBtp3.Name = "CBtp3";
            this.CBtp3.Size = new System.Drawing.Size(59, 17);
            this.CBtp3.TabIndex = 9;
            this.CBtp3.Text = "วีปคลีม";
            this.CBtp3.UseVisualStyleBackColor = true;
            this.CBtp3.CheckedChanged += new System.EventHandler(this.CBtp3_CheckedChanged);
            // 
            // CBtp4
            // 
            this.CBtp4.AutoSize = true;
            this.CBtp4.Location = new System.Drawing.Point(267, 387);
            this.CBtp4.Name = "CBtp4";
            this.CBtp4.Size = new System.Drawing.Size(51, 17);
            this.CBtp4.TabIndex = 10;
            this.CBtp4.Text = "ไข่มุข";
            this.CBtp4.UseVisualStyleBackColor = true;
            this.CBtp4.CheckedChanged += new System.EventHandler(this.CBtp4_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(149, 321);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "ท็อปปิ้ง";
            // 
            // BTadd
            // 
            this.BTadd.Location = new System.Drawing.Point(116, 451);
            this.BTadd.Name = "BTadd";
            this.BTadd.Size = new System.Drawing.Size(85, 41);
            this.BTadd.TabIndex = 13;
            this.BTadd.Text = "เพิ่มรายการ";
            this.BTadd.UseVisualStyleBackColor = true;
            this.BTadd.Click += new System.EventHandler(this.BTadd_Click);
            // 
            // CBT
            // 
            this.CBT.FormattingEnabled = true;
            this.CBT.Items.AddRange(new object[] {
            "ร้อน",
            "เย็น"});
            this.CBT.Location = new System.Drawing.Point(152, 169);
            this.CBT.Name = "CBT";
            this.CBT.Size = new System.Drawing.Size(85, 21);
            this.CBT.TabIndex = 14;
            this.CBT.SelectedIndexChanged += new System.EventHandler(this.CBT_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(149, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "ร้อน/เย็น";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // BTDL
            // 
            this.BTDL.Location = new System.Drawing.Point(207, 451);
            this.BTDL.Name = "BTDL";
            this.BTDL.Size = new System.Drawing.Size(85, 41);
            this.BTDL.TabIndex = 17;
            this.BTDL.Text = "ลบรายการ";
            this.BTDL.UseVisualStyleBackColor = true;
            this.BTDL.Click += new System.EventHandler(this.BTDL_Click);
            // 
            // BTCL
            // 
            this.BTCL.Location = new System.Drawing.Point(384, 451);
            this.BTCL.Name = "BTCL";
            this.BTCL.Size = new System.Drawing.Size(85, 41);
            this.BTCL.TabIndex = 18;
            this.BTCL.Text = "ยกเลิกออเดอร์";
            this.BTCL.UseVisualStyleBackColor = true;
            this.BTCL.Click += new System.EventHandler(this.BTCL_Click);
            // 
            // LBpr
            // 
            this.LBpr.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBpr.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBpr.Location = new System.Drawing.Point(503, 88);
            this.LBpr.Name = "LBpr";
            this.LBpr.Size = new System.Drawing.Size(100, 33);
            this.LBpr.TabIndex = 19;
            this.LBpr.Text = "0";
            this.LBpr.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(517, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 26);
            this.label6.TabIndex = 20;
            this.label6.Text = "ราคา";
            // 
            // NUD1
            // 
            this.NUD1.Location = new System.Drawing.Point(349, 101);
            this.NUD1.Name = "NUD1";
            this.NUD1.Size = new System.Drawing.Size(120, 20);
            this.NUD1.TabIndex = 21;
            this.NUD1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NUD1.ValueChanged += new System.EventHandler(this.NUD1_ValueChanged_1);
            // 
            // LBOrder
            // 
            this.LBOrder.AllowColumnReorder = true;
            this.LBOrder.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CH1,
            this.CH2,
            this.CH3,
            this.CHTP1,
            this.CHTP2,
            this.CHTP3,
            this.CHTP4,
            this.CH6,
            this.CH7});
            this.LBOrder.FullRowSelect = true;
            this.LBOrder.GridLines = true;
            this.LBOrder.Location = new System.Drawing.Point(624, 74);
            this.LBOrder.Name = "LBOrder";
            this.LBOrder.Size = new System.Drawing.Size(588, 402);
            this.LBOrder.TabIndex = 22;
            this.LBOrder.UseCompatibleStateImageBehavior = false;
            this.LBOrder.View = System.Windows.Forms.View.Details;
            this.LBOrder.SelectedIndexChanged += new System.EventHandler(this.LBOrder_SelectedIndexChanged_2);
            this.LBOrder.DoubleClick += new System.EventHandler(this.LBOrder_DoubleClick);
            // 
            // CH1
            // 
            this.CH1.Text = "ชนิดเครื่องดื่ม";
            // 
            // CH2
            // 
            this.CH2.Text = "ร้อน/เย็น";
            // 
            // CH3
            // 
            this.CH3.Text = "ความหวาน";
            // 
            // CHTP1
            // 
            this.CHTP1.Text = "เพิ่มช็อค";
            // 
            // CHTP2
            // 
            this.CHTP2.Text = "น้ำผึ้ง";
            // 
            // CHTP3
            // 
            this.CHTP3.Text = "วิปคลีม";
            // 
            // CHTP4
            // 
            this.CHTP4.Text = "ไข่มุก";
            // 
            // BTED
            // 
            this.BTED.Location = new System.Drawing.Point(293, 451);
            this.BTED.Name = "BTED";
            this.BTED.Size = new System.Drawing.Size(85, 41);
            this.BTED.TabIndex = 23;
            this.BTED.Text = "แก้ไขรายการ";
            this.BTED.UseVisualStyleBackColor = true;
            this.BTED.Click += new System.EventHandler(this.BTED_Click);
            // 
            // CH6
            // 
            this.CH6.Text = "จำนวน";
            // 
            // CH7
            // 
            this.CH7.Text = "ราคา";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1255, 541);
            this.Controls.Add(this.BTED);
            this.Controls.Add(this.LBOrder);
            this.Controls.Add(this.NUD1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.LBpr);
            this.Controls.Add(this.BTCL);
            this.Controls.Add(this.BTDL);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CBT);
            this.Controls.Add(this.BTadd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CBtp4);
            this.Controls.Add(this.CBtp3);
            this.Controls.Add(this.CBtp2);
            this.Controls.Add(this.CBtp1);
            this.Controls.Add(this.RBst4);
            this.Controls.Add(this.RBst3);
            this.Controls.Add(this.RBst2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.RBst1);
            this.Controls.Add(this.CBMenu);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.NUD1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CBMenu;
        private System.Windows.Forms.RadioButton RBst1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton RBst2;
        private System.Windows.Forms.RadioButton RBst3;
        private System.Windows.Forms.RadioButton RBst4;
        private System.Windows.Forms.CheckBox CBtp1;
        private System.Windows.Forms.CheckBox CBtp2;
        private System.Windows.Forms.CheckBox CBtp3;
        private System.Windows.Forms.CheckBox CBtp4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BTadd;
        private System.Windows.Forms.ComboBox CBT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BTDL;
        private System.Windows.Forms.Button BTCL;
        private System.Windows.Forms.Label LBpr;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown NUD1;
        private System.Windows.Forms.ListView LBOrder;
        private System.Windows.Forms.ColumnHeader CH1;
        private System.Windows.Forms.ColumnHeader CH3;
        private System.Windows.Forms.ColumnHeader CHTP1;
        private System.Windows.Forms.ColumnHeader CHTP2;
        private System.Windows.Forms.ColumnHeader CHTP3;
        private System.Windows.Forms.ColumnHeader CHTP4;
        private System.Windows.Forms.Button BTED;
        private System.Windows.Forms.ColumnHeader CH2;
        private System.Windows.Forms.ColumnHeader CH6;
        private System.Windows.Forms.ColumnHeader CH7;
    }
}

