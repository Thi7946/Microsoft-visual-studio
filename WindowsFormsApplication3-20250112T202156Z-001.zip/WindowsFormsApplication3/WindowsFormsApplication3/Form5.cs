﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        public static string PRF6;
        private void BTFD_Click(object sender, EventArgs e)
        {
            Form6 F6 = new Form6();
            F6.NUMF6 =Convert .ToInt32 (TBCT.Text);
            F6.ShowDialog ();
            LBPRFD.Text = PRF6;
        }
    }
}
