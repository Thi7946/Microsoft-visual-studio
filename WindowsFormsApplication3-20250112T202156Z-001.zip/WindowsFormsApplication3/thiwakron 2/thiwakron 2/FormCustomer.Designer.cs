﻿namespace thiwakron_2
{
    partial class FormCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DTGV_CT = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.CBSEX = new System.Windows.Forms.ComboBox();
            this.CBMEMBER = new System.Windows.Forms.ComboBox();
            this.DTPB = new System.Windows.Forms.DateTimePicker();
            this.TBAddress = new System.Windows.Forms.TextBox();
            this.TBName = new System.Windows.Forms.TextBox();
            this.TBSname = new System.Windows.Forms.TextBox();
            this.TBTel = new System.Windows.Forms.TextBox();
            this.BTAdd = new System.Windows.Forms.Button();
            this.BTDelete = new System.Windows.Forms.Button();
            this.BTEdit = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.BTSR = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.LBID = new System.Windows.Forms.Label();
            this.BTGenID = new System.Windows.Forms.Button();
            this.BTReset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DTGV_CT)).BeginInit();
            this.SuspendLayout();
            // 
            // DTGV_CT
            // 
            this.DTGV_CT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DTGV_CT.Location = new System.Drawing.Point(480, 72);
            this.DTGV_CT.Name = "DTGV_CT";
            this.DTGV_CT.Size = new System.Drawing.Size(661, 487);
            this.DTGV_CT.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "เลขสมาชิก";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "ชื่อ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(216, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 26);
            this.label3.TabIndex = 3;
            this.label3.Text = "นามสกุล";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 26);
            this.label4.TabIndex = 4;
            this.label4.Text = "ที่อยู่";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 329);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 26);
            this.label5.TabIndex = 5;
            this.label5.Text = "เพศ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 381);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 26);
            this.label6.TabIndex = 6;
            this.label6.Text = "หมายเลขมือถือ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 431);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 26);
            this.label7.TabIndex = 7;
            this.label7.Text = "วันเกิด";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 480);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 26);
            this.label8.TabIndex = 8;
            this.label8.Text = "ระดับสมาชิก";
            // 
            // CBSEX
            // 
            this.CBSEX.FormattingEnabled = true;
            this.CBSEX.Location = new System.Drawing.Point(100, 334);
            this.CBSEX.Name = "CBSEX";
            this.CBSEX.Size = new System.Drawing.Size(121, 21);
            this.CBSEX.TabIndex = 9;
            // 
            // CBMEMBER
            // 
            this.CBMEMBER.FormattingEnabled = true;
            this.CBMEMBER.Location = new System.Drawing.Point(134, 485);
            this.CBMEMBER.Name = "CBMEMBER";
            this.CBMEMBER.Size = new System.Drawing.Size(121, 21);
            this.CBMEMBER.TabIndex = 10;
            // 
            // DTPB
            // 
            this.DTPB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTPB.Location = new System.Drawing.Point(100, 437);
            this.DTPB.Name = "DTPB";
            this.DTPB.Size = new System.Drawing.Size(83, 20);
            this.DTPB.TabIndex = 11;
            // 
            // TBAddress
            // 
            this.TBAddress.Location = new System.Drawing.Point(88, 154);
            this.TBAddress.Multiline = true;
            this.TBAddress.Name = "TBAddress";
            this.TBAddress.Size = new System.Drawing.Size(333, 155);
            this.TBAddress.TabIndex = 15;
            // 
            // TBName
            // 
            this.TBName.Location = new System.Drawing.Point(54, 87);
            this.TBName.Multiline = true;
            this.TBName.Name = "TBName";
            this.TBName.Size = new System.Drawing.Size(129, 31);
            this.TBName.TabIndex = 16;
            // 
            // TBSname
            // 
            this.TBSname.Location = new System.Drawing.Point(305, 87);
            this.TBSname.Multiline = true;
            this.TBSname.Name = "TBSname";
            this.TBSname.Size = new System.Drawing.Size(129, 31);
            this.TBSname.TabIndex = 17;
            // 
            // TBTel
            // 
            this.TBTel.Location = new System.Drawing.Point(157, 381);
            this.TBTel.Multiline = true;
            this.TBTel.Name = "TBTel";
            this.TBTel.Size = new System.Drawing.Size(241, 31);
            this.TBTel.TabIndex = 18;
            // 
            // BTAdd
            // 
            this.BTAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTAdd.Location = new System.Drawing.Point(1169, 189);
            this.BTAdd.Name = "BTAdd";
            this.BTAdd.Size = new System.Drawing.Size(97, 80);
            this.BTAdd.TabIndex = 19;
            this.BTAdd.Text = "ADD";
            this.BTAdd.UseVisualStyleBackColor = true;
            this.BTAdd.Click += new System.EventHandler(this.BTAdd_Click);
            // 
            // BTDelete
            // 
            this.BTDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTDelete.Location = new System.Drawing.Point(1169, 53);
            this.BTDelete.Name = "BTDelete";
            this.BTDelete.Size = new System.Drawing.Size(97, 80);
            this.BTDelete.TabIndex = 20;
            this.BTDelete.Text = "Delete";
            this.BTDelete.UseVisualStyleBackColor = true;
            // 
            // BTEdit
            // 
            this.BTEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTEdit.Location = new System.Drawing.Point(1169, 310);
            this.BTEdit.Name = "BTEdit";
            this.BTEdit.Size = new System.Drawing.Size(97, 80);
            this.BTEdit.TabIndex = 21;
            this.BTEdit.Text = "Edit";
            this.BTEdit.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(576, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(329, 20);
            this.textBox1.TabIndex = 22;
            // 
            // BTSR
            // 
            this.BTSR.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTSR.Location = new System.Drawing.Point(930, 12);
            this.BTSR.Name = "BTSR";
            this.BTSR.Size = new System.Drawing.Size(113, 54);
            this.BTSR.TabIndex = 23;
            this.BTSR.Text = "ค้นหา";
            this.BTSR.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(497, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 26);
            this.label9.TabIndex = 24;
            this.label9.Text = "ค้นหา";
            // 
            // LBID
            // 
            this.LBID.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LBID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBID.Location = new System.Drawing.Point(152, 27);
            this.LBID.Name = "LBID";
            this.LBID.Size = new System.Drawing.Size(103, 26);
            this.LBID.TabIndex = 25;
            // 
            // BTGenID
            // 
            this.BTGenID.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTGenID.Location = new System.Drawing.Point(264, 20);
            this.BTGenID.Name = "BTGenID";
            this.BTGenID.Size = new System.Drawing.Size(157, 39);
            this.BTGenID.TabIndex = 26;
            this.BTGenID.Text = "สร้างเลขสมาชิก";
            this.BTGenID.UseVisualStyleBackColor = true;
            this.BTGenID.Click += new System.EventHandler(this.BTGenID_Click);
            // 
            // BTReset
            // 
            this.BTReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTReset.Location = new System.Drawing.Point(1169, 426);
            this.BTReset.Name = "BTReset";
            this.BTReset.Size = new System.Drawing.Size(97, 80);
            this.BTReset.TabIndex = 27;
            this.BTReset.Text = "Reset";
            this.BTReset.UseVisualStyleBackColor = true;
            this.BTReset.Click += new System.EventHandler(this.BTReset_Click);
            // 
            // FormCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1301, 596);
            this.Controls.Add(this.BTReset);
            this.Controls.Add(this.BTGenID);
            this.Controls.Add(this.LBID);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.BTSR);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.BTEdit);
            this.Controls.Add(this.BTDelete);
            this.Controls.Add(this.BTAdd);
            this.Controls.Add(this.TBTel);
            this.Controls.Add(this.TBSname);
            this.Controls.Add(this.TBName);
            this.Controls.Add(this.TBAddress);
            this.Controls.Add(this.DTPB);
            this.Controls.Add(this.CBMEMBER);
            this.Controls.Add(this.CBSEX);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DTGV_CT);
            this.Name = "FormCustomer";
            this.Text = "FormCustomer";
            this.Load += new System.EventHandler(this.FormCustomer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DTGV_CT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DTGV_CT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox CBSEX;
        private System.Windows.Forms.ComboBox CBMEMBER;
        private System.Windows.Forms.DateTimePicker DTPB;
        private System.Windows.Forms.TextBox TBAddress;
        private System.Windows.Forms.TextBox TBName;
        private System.Windows.Forms.TextBox TBSname;
        private System.Windows.Forms.TextBox TBTel;
        private System.Windows.Forms.Button BTAdd;
        private System.Windows.Forms.Button BTDelete;
        private System.Windows.Forms.Button BTEdit;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button BTSR;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label LBID;
        private System.Windows.Forms.Button BTGenID;
        private System.Windows.Forms.Button BTReset;
    }
}