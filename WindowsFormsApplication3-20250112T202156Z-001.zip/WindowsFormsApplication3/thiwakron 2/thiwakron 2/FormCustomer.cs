﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace thiwakron_2
{
    public partial class FormCustomer : Form
    {
        public FormCustomer()
        {
            InitializeComponent();
        }
        DataSet ds = new DataSet();
        private void FormCustomer_Load(object sender, EventArgs e)
        {
            string sql = "SELECT * FROM View_CT";
            SqlDataAdapter da = new SqlDataAdapter(sql, Form1.DATA);
            da.Fill(ds, "ViewCT");
            DTGV_CT.DataSource = ds.Tables["ViewCT"];
            string sql2 = "SELECT * FROM Table_TblSex";
            string sql3 = "SELECT * FROM Table_Tbl_Member";
            da = new SqlDataAdapter(sql2, Form1. DATA);
            da.Fill(ds, "typesex");
            CBSEX.DisplayMember = "NameSex";
            CBSEX.ValueMember = "TypeSex";
            CBSEX.DataSource = ds.Tables["typesex"];
            da = new SqlDataAdapter(sql3, Form1. DATA);
            da.Fill(ds, "Typemember");
            CBMEMBER.DisplayMember = "NameMember";
            CBMEMBER.ValueMember = "TypeMember";
            CBMEMBER.DataSource = ds.Tables["typemember"];
            BTEdit.Enabled = false;
            BTDelete.Enabled = false;
        }

        private void BTGenID_Click(object sender, EventArgs e)
        {
            string id1 = "SELECT TOP 1 * FROM Table_TblCT ORDER BY IDCT DESC";
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(id1, Form1.DATA);
            da.Fill(dt);
            int Topid = Convert.ToInt32(dt.Rows[0]["IDCT"]) + 1;
            LBID.Text = Topid.ToString();
            BTSR.Enabled = false;
        }

        private void Updatedata()
        {
            string sql = "SELECT * FROM Table_TblCT";
            SqlDataAdapter da = new SqlDataAdapter(sql, Form1.DATA);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(ds, "CT");
        }

        private void BTReset_Click(object sender, EventArgs e)
        {
            LBID.Text = "";
            TBName.Text = "";
            TBSname.Text = "";
            TBAddress.Text = "";
            TBTel .Text = "";
            CBSEX.SelectedIndex = 1;
            CBMEMBER.SelectedIndex = 1;
            DTPB.ResetText();
            BTSR.Enabled = true;
        }

        private void BTAdd_Click(object sender, EventArgs e)
        {
            DataSet ds2 = new DataSet();
            string sql = "SELECT * FROM Table_TblCT";
            SqlDataAdapter da = new SqlDataAdapter(sql, Form1.DATA);
            da.Fill(ds, "CT");
            DataRow[] drs = ds.Tables["CT"].Select("IDCT= '" + LBID.Text + "'");
            if (drs.Length == 0)
            {
                DataRow dr = ds.Tables["CT"].NewRow();
                dr["IDCT"] = LBID.Text;
                dr["IDMEMBER"] = LBID.Text;
                dr["NameCT"] = TBName.Text;
                dr["SnameCT"] = TBSname.Text;
                dr["AddressCT"] = TBAddress.Text;
                dr["TelCT"] = TBTel.Text;
                dr["BDCT"] = DTPB.Text;
                dr["TypeSex"] = CBSEX.SelectedValue;
                dr["TypeMember"] = CBMEMBER.SelectedValue;
                ds.Tables["CT"].Rows.Add(dr);
                Updatedata();
                string sql1 = "SELECT * FROM View_CT";
                SqlDataAdapter da2 = new SqlDataAdapter(sql1, Form1.DATA);
                da2.Fill(ds2, "ViewCT");
            }
            else
            {
                MessageBox.Show("เลข ID ซ้ำ", "ERORR");
            }
            DTGV_CT.DataSource = ds2.Tables["ViewCT"];
        }
        
    }
}
